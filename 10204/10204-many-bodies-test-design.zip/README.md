# Test design for #10204 (highlight with many bodies selected)

Made with SolidCraft itself; no customer data.

- `many_bodies.py ROWS PER_ROW` writes a command script: ROWS rows of three seeds (an 8 mm box,
  a cylinder of radius 4 mm, a sphere of radius 4 mm), each patterned PER_ROW times along X, so
  the design has 3 x ROWS x PER_ROW bodies (Body1 .. BodyN).
- `many-bodies-1440.solidcraft`: made with

      python3 many_bodies.py 20 24 > many-bodies.json
      solidcraft-cli run many-bodies.json --quiet --save many-bodies-1440.solidcraft

- `bench_runs.sh ROUNDS DESIGN LOG TEST_BIN...`: the headless measurement
  (`scale_tests::many_selected_bodies_hover_cost`) with each release test binary in turn
  (`SOLIDCRAFT_SCALE_LOOP=61` for 61 hover changes per run).
- `selected_hover.py`: frame time (`ui.inspect` `frame_ms`) while the pointer moves over 60
  points of the design in a running app (`solidcraft --control PORT`) with every body selected,
  and a close-up screenshot with the pointer on one face.
- `selected_hover_runs.sh DESIGN ROUNDS APP_A APP_B OUTDIR`: `selected_hover.py` with two app
  builds alternating, each under its own `xvfb-run` with the software renderer.
