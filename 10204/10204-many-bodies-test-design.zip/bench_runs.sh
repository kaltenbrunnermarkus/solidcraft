#!/bin/bash
# bench_runs.sh ROUNDS DESIGN LOG BIN...: the headless measurement
# (scale_tests::many_selected_bodies_hover_cost) with each release test binary in turn, ROUNDS
# rounds, the load noted per run.
set -u
ROUNDS=$1; DESIGN=$2; LOG=$3; shift 3
export SOLIDCRAFT_GPU=software WGPU_BACKEND=vulkan VK_DRIVER_FILES=/usr/share/vulkan/icd.d/lvp_icd.json
[ -n "$DESIGN" ] && export SOLIDCRAFT_SCALE_DESIGN=$DESIGN
for r in $(seq 1 "$ROUNDS"); do
  for BIN in "$@"; do
    echo "run $r $(basename "$BIN") load $(cut -d' ' -f1-3 /proc/loadavg)" >> "$LOG"
    "$BIN" --ignored --nocapture --exact scale_tests::many_selected_bodies_hover_cost 2>&1 | grep MANYSEL | sed "s/^/$(basename "$BIN") $r /" >> "$LOG"
  done
done
echo DONE >> "$LOG"
