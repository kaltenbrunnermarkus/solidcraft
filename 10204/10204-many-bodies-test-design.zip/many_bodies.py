#!/usr/bin/env python3
"""Write a SolidCraft command script: a design of many simple bodies (boxes, cylinders, spheres).

    python3 many_bodies.py ROWS PER_ROW > many-bodies.json
    solidcraft-cli run many-bodies.json --save many-bodies.solidcraft

Each row is three seeds (a box, a cylinder, a sphere), each patterned PER_ROW times along X, so
the design has 3 * ROWS * PER_ROW bodies. Selecting every body and moving the pointer over the
model lights every body whole on each hover change.
"""
import json
import sys

rows = int(sys.argv[1]) if len(sys.argv) > 1 else 20
per = int(sys.argv[2]) if len(sys.argv) > 2 else 24
steps = []
for r in range(rows):
    y = 30.0 * r
    seeds = [
        ("solid.box", {"length": 8, "width": 8, "height": 8, "center": [0, y, 4], "operation": "new", "name": f"Box{r}"}),
        ("solid.cylinder", {"base": [0, y + 10, 0], "radius": 4, "height": 10, "operation": "new", "name": f"Cyl{r}"}),
        ("solid.sphere", {"center": [0, y + 20, 4], "radius": 4, "operation": "new", "name": f"Ball{r}"}),
    ]
    for cmd, p in seeds:
        steps.append({"command": cmd, "params": p})
        if per > 1:
            steps.append({
                "command": "solid.pattern.rectangular",
                "params": {"features": [p["name"]], "dir1": [1, 0, 0], "count1": per, "spacing1": 12, "name": f"Row{p['name']}"},
            })
json.dump(steps, sys.stdout, indent=1)
