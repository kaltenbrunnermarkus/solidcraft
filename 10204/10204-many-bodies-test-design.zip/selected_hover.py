#!/usr/bin/env python3
"""Frame time while the pointer hovers a design with every body selected, in a running SolidCraft
(`solidcraft --control PORT`), and a screenshot of the highlight.

    solidcraft --control 7899 &
    python3 selected_hover.py --port 7899 --shot out.png many-bodies-1440.solidcraft

Opens the design, shows it from the iso view fitted, selects every body (`select.set` over the
control channel: Body1 .. BodyN), then moves the pointer over a fixed grid of points across the
model (no button), reading `ui.inspect` `frame_ms` (CPU time of the UI frame) after each move.
Prints one JSON line per round: median, p90, min and max frame_ms over the moves that changed
what is hovered (each builds the highlight again) and over all moves. With --shot, the pointer
then rests on the view's centre and the window is saved there.
"""
import argparse
import json
import os
import statistics
import sys
import time

# The control-channel client from a SolidCraft checkout (SOLIDCRAFT_REPO, default the current folder).
sys.path.insert(0, os.path.join(os.environ.get("SOLIDCRAFT_REPO", os.getcwd()), "examples", "demo"))
from enclosure_mcp import control  # noqa: E402


def stats(v):
    if not v:
        return None
    v = sorted(v)
    return {"n": len(v), "median_ms": round(statistics.median(v), 3), "p90_ms": round(v[max(0, int(len(v) * 0.9) - 1)], 3),
            "min_ms": round(v[0], 3), "max_ms": round(v[-1], 3)}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("design")
    ap.add_argument("--port", type=int, default=7899)
    ap.add_argument("--moves", type=int, default=60)
    ap.add_argument("--rounds", type=int, default=2)
    ap.add_argument("--settle", type=float, default=20, help="seconds to wait at most for the view to show the model")
    ap.add_argument("--shot", help="save a screenshot of the window here, pointer on the view's centre")
    a = ap.parse_args()

    def ui(method, params=None):
        r = control(a.port, method, params)
        if not r.get("ok", False):
            raise RuntimeError(f"{method}: {r.get('error')}")
        return r.get("result")

    ui("ui.resize", {"width": 1600, "height": 1000})
    ui("ui.home", {"open": False})
    ui("ui.file", {"path": os.path.abspath(a.design)})
    time.sleep(1)
    while ui("ui.inspect").get("file_busy"):
        time.sleep(0.5)
    ui("ui.home", {"open": False})
    ui("ui.set", {"showSketches": False, "showOrigin": False})
    ui("ui.view", {"view": "iso"})
    # The design is opened and evaluated in the background: fit once it shows something.
    t0 = time.time()
    while True:
        r = control(a.port, "ui.camera", {"fit": True})
        if r.get("ok", False) or time.time() - t0 > a.settle:
            break
        time.sleep(1)
    print(json.dumps({"shown_after_s": round(time.time() - t0, 1)}), flush=True)
    time.sleep(3)
    vx, vy, vw, vh = ui("ui.inspect")["viewport"]
    t1 = time.time()
    while time.time() - t1 < a.settle:
        ui("ui.move", {"x": vx + vw * 0.5, "y": vy + vh * 0.5})
        if (ui("ui.inspect").get("draw") or {}).get("triangles", 0) > 0:
            break
        time.sleep(1)
    ui("ui.camera", {"fit": True})
    time.sleep(2)
    # The generated design's bodies are Body1 .. BodyN (BODIES, default 1,440).
    names = [f"Body{i}" for i in range(1, int(os.environ.get("BODIES", "1440")) + 1)]
    ui("engine.execute", {"command": "select.set", "params": {"items": [{"type": "body", "name": n} for n in names]}})
    time.sleep(1)
    print(json.dumps({"selected": len(ui("ui.selection").get("selection", [])), "draw": ui("ui.inspect").get("draw")}), flush=True)
    vx, vy, vw, vh = ui("ui.inspect")["viewport"]
    cols = 10
    rows = max(1, a.moves // cols)
    points = [(vx + vw * (0.25 + 0.5 * c / (cols - 1)), vy + vh * (0.3 + 0.4 * r / max(1, rows - 1))) for r in range(rows) for c in range(cols)]
    for rnd in range(a.rounds):
        changed, every, last = [], [], None
        for x, y in points:
            ui("ui.move", {"x": x, "y": y})
            time.sleep(0.05)
            st = ui("ui.inspect")
            every.append(st["frame_ms"])
            if st["hover"] != last:
                changed.append(st["frame_ms"])
            last = st["hover"]
        print(json.dumps({"round": rnd, "hover_changes": stats(changed), "all_moves": stats(every)}), flush=True)
    if a.shot:
        # Up close, about the fitted view's centre, so the lit bodies and the hovered face show.
        target = ui("ui.inspect")["camera"]["target"]
        ui("ui.camera", {"target": target, "distance": 120})
        time.sleep(1)
        ui("ui.move", {"x": vx + vw * 0.5 + 40, "y": vy + vh * 0.5 + 40})
        time.sleep(0.5)
        ui("ui.move", {"x": vx + vw * 0.5, "y": vy + vh * 0.5})
        time.sleep(1.5)
        ui("ui.screenshot", {"path": os.path.abspath(a.shot)})
        time.sleep(1.5)
        print(json.dumps({"shot": a.shot, "hover": ui("ui.inspect").get("hover")}), flush=True)


if __name__ == "__main__":
    main()
