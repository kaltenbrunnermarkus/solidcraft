#!/bin/bash
# selected_hover_runs.sh DESIGN ROUNDS APP_A APP_B OUTDIR: selected_hover.py on two app builds
# alternating (A B A B ...), ROUNDS runs each, each under its own xvfb-run with the software
# renderer; the app is quit over the control channel (app.quit). The last run of each build
# saves a screenshot (OUTDIR/A.png, OUTDIR/B.png). Settings live in OUTDIR/state-RUN-BUILD. Run it from a
# SolidCraft checkout (or set SOLIDCRAFT_REPO): it uses examples/demo/enclosure_mcp.py.
set -u
DESIGN=$(realpath "$1"); ROUNDS=$2; A=$(realpath "$3"); B=$(realpath "$4"); mkdir -p "$5"; OUT=$(realpath "$5")
HERE=$(cd "$(dirname "$0")" && pwd)
export SOLIDCRAFT_REPO=${SOLIDCRAFT_REPO:-$PWD}
REPO=$SOLIDCRAFT_REPO
export SOLIDCRAFT_GPU=software WGPU_BACKEND=vulkan VK_DRIVER_FILES=/usr/share/vulkan/icd.d/lvp_icd.json
LOG=$OUT/runs.log
PORT=7911
for r in $(seq 1 "$ROUNDS"); do
  for v in A B; do
    BIN=$A; [ "$v" = B ] && BIN=$B
    # Settings of its own per run: a run quit with its design unsaved leaves an autosave, which
    # the next app start would offer to recover (a dialog over the view).
    mkdir -p "$OUT/state-$r-$v/config" "$OUT/state-$r-$v/data"
    export XDG_CONFIG_HOME=$OUT/state-$r-$v/config XDG_DATA_HOME=$OUT/state-$r-$v/data
    echo "run $r $v load $(cut -d' ' -f1-3 /proc/loadavg)" >> "$LOG"
    xvfb-run -a -s "-screen 0 1920x1080x24" "$BIN" --control $PORT > "$OUT/app-$r-$v.log" 2>&1 &
    for i in $(seq 1 120); do
      python3 -c "import socket; socket.create_connection(('127.0.0.1', $PORT), 1)" 2>/dev/null && break
      sleep 1
    done
    sleep 2
    # A copy per run: the app locks the design it opens (a second open asks first).
    cp "$DESIGN" "$OUT/run-$r-$v.solidcraft"
    SHOT=()
    [ "$r" = "$ROUNDS" ] && SHOT=(--shot "$OUT/$v.png")
    python3 "$HERE/selected_hover.py" --port $PORT "${SHOT[@]}" "$OUT/run-$r-$v.solidcraft" 2>&1 | sed "s/^/$v $r /" >> "$LOG"
    python3 -c "
import sys; sys.path.insert(0, '$REPO/examples/demo')
from enclosure_mcp import control
control($PORT, 'app.quit', {'force': True})" > /dev/null 2>&1
    wait
  done
done
echo DONE >> "$LOG"
