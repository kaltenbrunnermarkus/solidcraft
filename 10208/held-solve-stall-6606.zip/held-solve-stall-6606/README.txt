Test data for "Sketch: held solves that cannot succeed give up sooner (#6606)".

scripts/       120 generated sketch scripts (sN.json, seeds 0-119): sketches, constraints, 2,873 drags.
               Generated with tools/sketch_script_generator.rs (an engine example; random commands,
               only the ones that succeed are kept, so each replays without an error).
tools/replay.sh <cli> <dir>     runs every script with --results --timings
tools/savepass.sh <cli> <dir>   saves every script's final design
tools/compare.py <resA> <resB> <saveA> <saveB>   compares results and saved designs
tools/instrument.py             writes a solver.rs copy that logs every LM run ($SC_LM_TRACE)
tools/margin_stream.py <trace.jsonl...>          checks the stall rule against logged runs
bench-corpus.txt, bench-ab.txt  timings main vs branch (3 interleaved runs, shared machine)
