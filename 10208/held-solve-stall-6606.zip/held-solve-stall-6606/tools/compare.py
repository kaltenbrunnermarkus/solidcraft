import json,glob,sys,zipfile,os
a,b=sys.argv[1],sys.argv[2]
names=sorted(os.path.basename(f) for f in glob.glob(a+'/*.json'))
same=diff=0; ta=tb=0; drags=0
for n in names:
    try: ja=json.load(open(f'{a}/{n}')); jb=json.load(open(f'{b}/{n}'))
    except Exception as e: print('unreadable',n,e); diff+=1; continue
    if ja['results']==jb['results']: same+=1
    else:
        diff+=1; print('DIFF results',n)
    ta+=ja['total_ms']; tb+=jb['total_ms']
    drags+=sum(1 for t in ja['timings'] if t['command']=='sketch.drag')
print(f"results: {same} identical, {diff} different; drags {drags}; total ms {ta:.0f} vs {tb:.0f}")
if len(sys.argv)>4:
    sa,sb=sys.argv[3],sys.argv[4]; s=d=0
    for dd in sorted(glob.glob(sa+'/*/')):
        n=os.path.basename(dd.rstrip('/'))
        za=zipfile.ZipFile(f'{sa}/{n}/design.sc'); zb=zipfile.ZipFile(f'{sb}/{n}/design.sc')
        if za.read('document.json')==zb.read('document.json') and za.read('container.json')==zb.read('container.json'): s+=1
        else: d+=1; print('DIFF design',n)
    print(f"designs: {s} byte-identical, {d} different")
