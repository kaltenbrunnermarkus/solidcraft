# Throwaway: writes an instrumented copy of solver.rs (LM trace as JSON lines to $SC_LM_TRACE).
import sys
src, dst = sys.argv[1], sys.argv[2]
s = open(src).read()
def rep(old, new, count=1):
    global s
    assert s.count(old) == count, (old, s.count(old))
    s = s.replace(old, new)

TRACE = r'''
pub(crate) mod lmtrace {
    use std::cell::RefCell;
    use std::io::Write;
    use std::sync::Mutex;
    static FILE: Mutex<Option<std::fs::File>> = Mutex::new(None);
    thread_local! {
        pub static CTX: RefCell<String> = const { RefCell::new(String::new()) };
        pub static SITE: RefCell<&'static str> = const { RefCell::new("other") };
        pub static RUNS: RefCell<(usize, usize)> = const { RefCell::new((0, 0)) };
        pub static DUMP: RefCell<String> = const { RefCell::new(String::new()) };
    }
    pub fn on() -> bool { std::env::var_os("SC_LM_TRACE").is_some() }
    pub fn write(line: String) {
        let Some(path) = std::env::var_os("SC_LM_TRACE") else { return };
        let Ok(mut g) = FILE.lock() else { return };
        if g.is_none() { *g = std::fs::OpenOptions::new().create(true).append(true).open(path).ok(); }
        if let Some(f) = g.as_mut() { let _ = writeln!(f, "{line}"); }
    }
    pub fn site(s: &'static str) { SITE.with(|c| *c.borrow_mut() = s); }
    pub struct Run { pub n: usize, pub rows: usize, pub f0: f64, pub f: Vec<f64>, pub att: Vec<usize>, pub lam: Vec<f64>, pub site: &'static str, pub t: std::time::Instant }
    impl Run {
        pub fn new(n: usize, rows: usize, f0: f64) -> Self {
            let site = SITE.with(|c| std::mem::replace(&mut *c.borrow_mut(), "other"));
            Run { n, rows, f0, f: Vec::new(), att: Vec::new(), lam: Vec::new(), site, t: std::time::Instant::now() }
        }
        pub fn finish(&self, why: &str, end: f64) {
            RUNS.with(|c| { let mut c = c.borrow_mut(); c.0 += 1; c.1 += self.f.len(); });
            if !on() { return; }
            if why == "limit" && !(end < 1e-6) && self.n <= 12 {
                let d = DUMP.with(|c| std::mem::take(&mut *c.borrow_mut()));
                if !d.is_empty() { write(d); }
            }
            let ctx = CTX.with(|c| c.borrow().clone());
            let fs: Vec<String> = self.f.iter().map(|v| format!("{v:e}")).collect();
            let ls: Vec<String> = self.lam.iter().map(|v| format!("{v:e}")).collect();
            write(format!("{{\"kind\":\"lm\",\"ctx\":\"{ctx}\",\"site\":\"{}\",\"n\":{},\"rows\":{},\"f0\":{:e},\"end\":{:e},\"why\":\"{why}\",\"us\":{},\"f\":[{}],\"att\":{:?},\"lam\":[{}]}}",
                self.site, self.n, self.rows, self.f0, end, self.t.elapsed().as_micros(), fs.join(","), self.att, ls.join(",")));
        }
    }
}
'''
rep("const MAX_ITERS: usize = 500;", TRACE + "\nconst MAX_ITERS: usize = 500;")
# LM loop
rep("""    let mut f = norm2(&r);
    #[cfg(feature = "solver-profiling")]
    let run = profiling::start_run(n, r.len(), max_iters, f);
""", """    let mut f = norm2(&r);
    #[cfg(feature = "solver-profiling")]
    let run = profiling::start_run(n, r.len(), max_iters, f);
    let mut tr = lmtrace::Run::new(n, r.len(), f);
""")
rep("""            profiling::finish_run(run, StopReason::ResidualTolerance, max_abs(&r));
            return Some((it, max_abs(&r)));""", """            profiling::finish_run(run, StopReason::ResidualTolerance, max_abs(&r));
            tr.finish("tol", max_abs(&r));
            return Some((it, max_abs(&r)));""")
rep("""        for _attempt in 0..30 {
            let linear_work""", """        let mut tries = 0usize;
        for _attempt in 0..30 {
            tries += 1;
            let linear_work""")
rep("""                lambda = (lambda / 3.0).max(1e-12);
                improved = true;""", """                lambda = (lambda / 3.0).max(1e-12);
                improved = true;
                tr.f.push(f); tr.att.push(tries); tr.lam.push(lambda);""")
rep("""            profiling::finish_run(run, StopReason::NoImprovement, max_abs(&r));
            return Some((it, max_abs(&r)));""", """            profiling::finish_run(run, StopReason::NoImprovement, max_abs(&r));
            tr.f.push(f); tr.att.push(tries); tr.lam.push(lambda);
            tr.finish("noimp", max_abs(&r));
            return Some((it, max_abs(&r)));""")
rep("""    profiling::finish_run(run, StopReason::IterationLimit, max_abs(&r));
    Some((max_iters, max_abs(&r)))""", """    profiling::finish_run(run, StopReason::IterationLimit, max_abs(&r));
    tr.finish("limit", max_abs(&r));
    Some((max_iters, max_abs(&r)))""")
# solve_inner context + timing
rep("""    sk.prune_patterns();
    sk.refresh_pattern_shapes();
    let mut orientation_before = Vec::new();""", """    let trace_t = std::time::Instant::now();
    lmtrace::RUNS.with(|c| *c.borrow_mut() = (0, 0));
    lmtrace::CTX.with(|c| *c.borrow_mut() = format!("{:?}|ref={}|old={}|hold={}|numeric={}", analysis, reference.is_some(), old_values.is_some(), !(hold.points.is_empty() && hold.radii.is_empty()), budget.counts_numeric()));
    if std::env::var_os("SC_LM_DUMP").is_some() {
        let d = format!("{{\\"kind\\":\\"dump\\",\\"ctx\\":\\"{}\\",\\"hold_points\\":{:?},\\"hold_radii\\":{:?},\\"reference\\":{},\\"sketch\\":{}}}",
            lmtrace::CTX.with(|c| c.borrow().clone()), hold.points, hold.radii,
            format!("{:?}", format!("{:?}", reference)),
            format!("{:?}", format!("{:?}", sk)));
        lmtrace::DUMP.with(|c| *c.borrow_mut() = d);
    }
    sk.prune_patterns();
    sk.refresh_pattern_shapes();
    let mut orientation_before = Vec::new();""")
rep("""                    let (its, r) = if rest.is_empty() { (0, 0.0) } else { lm_in(sk, &lay, &rest_blocks, &rest, &mut x, &col, budget) };""",
    """                    lmtrace::site("rest");
                    let (its, r) = if rest.is_empty() { (0, 0.0) } else { lm_in(sk, &lay, &rest_blocks, &rest, &mut x, &col, budget) };""")
rep("""            if !(solved || pinned_failed && reseeded.is_some()) {
                let (its, r) = lm_in(""", """            if !(solved || pinned_failed && reseeded.is_some()) {
                lmtrace::site("whole");
                let (its, r) = lm_in(""")
rep("""                    *s = plain.get(v).copied().flatten().unwrap_or(*s0);
                    }
                }
                let (its, r) = lm_in(""", """                    *s = plain.get(v).copied().flatten().unwrap_or(*s0);
                    }
                }
                lmtrace::site("plain");
                let (its, r) = lm_in(""")
rep("""    let status = if max_residual < ACCEPT { SolveStatus::Solved } else { SolveStatus::Failed };
""", """    let status = if max_residual < ACCEPT { SolveStatus::Solved } else { SolveStatus::Failed };
    if lmtrace::on() {
        let ctx = lmtrace::CTX.with(|c| c.borrow().clone());
        let (runs, its) = lmtrace::RUNS.with(|c| *c.borrow());
        lmtrace::write(format!("{{\\"kind\\":\\"solve\\",\\"ctx\\":\\"{ctx}\\",\\"ok\\":{},\\"us\\":{},\\"lm_runs\\":{runs},\\"iters\\":{its},\\"comps\\":{}}}", status == SolveStatus::Solved, trace_t.elapsed().as_micros(), comps.len()));
    }
""")
open(dst, 'w').write(s)
print("ok")
