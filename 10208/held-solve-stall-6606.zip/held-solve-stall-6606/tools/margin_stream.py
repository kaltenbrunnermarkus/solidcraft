# Streaming check of the chosen rule on traces: W=20, eps=1e-5, guard f>1e-8 (superset of max residual > 1e-4).
import json,sys
W=20; EPS=1e-5; F=1e-8
okn=badn=0; worst=(1,None); fired_ok=0; tot=sa=0; caught=0
for path in sys.argv[1:]:
    for line in open(path):
        if '"kind":"lm"' not in line: continue
        try: o=json.loads(line.replace(':inf',':1e999').replace(':NaN',':null'))
        except Exception: continue
        if o['site'] not in ('whole','rest','plain') or o['end'] is None or any(v is None for v in o['f']): continue
        fs=[o['f0']]+o['f']
        if o['end']<1e-6:
            okn+=1
            for i in range(W,len(fs)):
                if fs[i]>F:
                    d=(fs[i-W]-fs[i])/fs[i-W]
                    if d<worst[0]: worst=(d,(path[-12:],o['ctx'],o['n'],i,len(fs)-1,fs[i]))
                    if d<=EPS: fired_ok+=1; break
        else:
            badn+=1; a=sum(o['att']); tot+=a
            for i in range(W,len(fs)):
                if fs[i]>F and fs[i-W]-fs[i]<=EPS*fs[i-W]: sa+=sum(o['att'][i:]); caught+=1; break
print(f"ok runs {okn}, rule fires on ok runs: {fired_ok}; smallest ok 20-iteration decrease {worst[0]:.3e} {worst[1]}")
print(f"failing runs {badn}, caught {caught}, attempts saved {sa/max(tot,1):.1%}")
