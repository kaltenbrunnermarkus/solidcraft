#!/bin/bash
# replay.sh <cli> <outdir> : runs every corpus script + drag.json, writes results JSON per script
cli=$1; out=$2; mkdir -p $out
for f in data/drag.json data/drag-orig.json corpus/s*.json; do
  b=$(basename $f .json)
  $cli run $f --results --timings > $out/$b.json 2> $out/$b.err
done
touch $out/.FERTIG
