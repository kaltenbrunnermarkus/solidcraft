#!/bin/bash
# savepass.sh <cli> <outdir>: saves the final design of each script as <outdir>/<name>/design.sc
cli=$1; out=$2
for f in data/drag.json corpus/s*.json; do
  b=$(basename $f .json); mkdir -p $out/$b
  $cli run $f --save $out/$b/design.sc --quiet 2> $out/$b/err.txt
done
touch $out/.FERTIG
