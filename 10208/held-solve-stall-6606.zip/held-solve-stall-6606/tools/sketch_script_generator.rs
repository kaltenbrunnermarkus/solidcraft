//! LOCAL THROWAWAY TOOL (not committed): random sketch scripts with constraints and drags.
//! `local_sketch_fuzz <out_dir> <from_seed> <count> [commands]` writes `s<seed>.json` with only
//! the commands that succeeded, so each script replays without an error.
use std::error::Error;

use serde_json::{Value, json};
use solidcraft_engine::Session;

struct Rng(u64);
impl Rng {
    fn next(&mut self) -> u64 {
        self.0 = self.0.wrapping_mul(6364136223846793005).wrapping_add(1442695040888963407);
        self.0 >> 33
    }
    fn below(&mut self, n: u64) -> u64 {
        self.next() % n.max(1)
    }
    fn coord(&mut self) -> i64 {
        self.below(61) as i64 - 30
    }
    fn pt(&mut self) -> Value {
        json!([self.coord(), self.coord()])
    }
}

fn names(s: &Session) -> (Vec<(String, f64, f64)>, Vec<String>, Vec<String>) {
    let mut points = Vec::new();
    let mut lines = Vec::new();
    let mut curves = Vec::new();
    if let Some(id) = s.active_sketch
        && let Ok(sk) = s.doc.sketch(id)
    {
        for p in &sk.points {
            points.push((p.id.clone(), p.pos.x, p.pos.y));
        }
        for c in &sk.curves {
            if matches!(c.kind, solidcraft_sketch::CurveKind::Line { .. }) {
                lines.push(c.id.clone());
            }
            curves.push(c.id.clone());
        }
    }
    (points, lines, curves)
}

fn command(r: &mut Rng, s: &Session) -> (String, Value) {
    let (points, lines, curves) = names(s);
    let pick = |r: &mut Rng, v: &[String]| v.get(r.below(v.len() as u64) as usize).cloned().unwrap_or_else(|| "l1".into());
    let ppick = |r: &mut Rng| points.get(r.below(points.len() as u64) as usize).cloned().unwrap_or(("p1".into(), 0.0, 0.0));
    let k = r.below(100);
    match k {
        0..=7 => ("sketch.line".into(), json!({"points": [r.pt(), r.pt()]})),
        8..=11 => ("sketch.line".into(), json!({"closed": r.below(2) == 0, "points": [r.pt(), r.pt(), r.pt(), r.pt()]})),
        12..=17 => ("sketch.rectangle.two_point".into(), json!({"p0": r.pt(), "p1": r.pt()})),
        18..=23 => ("sketch.arc.three_point".into(), json!({"start": r.pt(), "through": r.pt(), "end": r.pt()})),
        24..=28 => ("sketch.circle.center".into(), json!({"center": r.pt(), "radius": 1 + r.below(15)})),
        29..=31 => ("sketch.constraint.fix".into(), json!({"entity": ppick(r).0})),
        32..=35 => ("sketch.constraint.coincident".into(), json!({"a": ppick(r).0, "b": ppick(r).0})),
        36..=39 => ("sketch.constraint.horizontal_vertical".into(), json!({"line": pick(r, &lines)})),
        40..=42 => ("sketch.constraint.parallel".into(), json!({"a": pick(r, &lines), "b": pick(r, &lines)})),
        43..=45 => ("sketch.constraint.perpendicular".into(), json!({"a": pick(r, &lines), "b": pick(r, &lines)})),
        46..=48 => ("sketch.constraint.equal".into(), json!({"a": pick(r, &lines), "b": pick(r, &lines)})),
        49..=52 => ("sketch.constraint.tangent".into(), json!({"a": pick(r, &curves), "b": pick(r, &curves)})),
        53..=54 => ("sketch.constraint.concentric".into(), json!({"a": pick(r, &curves), "b": pick(r, &curves)})),
        55..=57 => ("sketch.constraint.midpoint".into(), json!({"line": pick(r, &lines), "point": ppick(r).0})),
        58..=62 => ("sketch.dimension".into(), json!({"entities": [ppick(r).0, ppick(r).0], "value": 1 + r.below(40)})),
        63..=64 => ("sketch.dimension".into(), json!({"entities": [pick(r, &lines)], "value": 1 + r.below(40)})),
        65..=66 => ("sketch.dimension".into(), json!({"entities": [pick(r, &lines), pick(r, &lines)], "type": "angle", "value": 5 + r.below(170)})),
        67..=68 => ("edit.undo".into(), json!({})),
        _ => {
            let (id, x, y) = ppick(r);
            ("sketch.drag".into(), json!({"entity": id, "from": [x, y], "to": r.pt()}))
        }
    }
}

fn main() -> Result<(), Box<dyn Error>> {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let dir = args.first().ok_or("out dir")?.clone();
    let from: u64 = args.get(1).ok_or("from")?.parse()?;
    let count: u64 = args.get(2).ok_or("count")?.parse()?;
    let len: usize = args.get(3).map_or(Ok(70), |v| v.parse())?;
    for seed in from..from + count {
        let mut r = Rng(seed.wrapping_mul(0x9E3779B97F4A7C15) ^ 0x5DEECE66D);
        let mut s = Session::default();
        let mut kept = vec![json!({"command": "sketch.create", "params": {"plane": "XY"}})];
        s.execute("sketch.create", &json!({"plane": "XY"}))?;
        let mut tries = 0;
        let mut drags = 0;
        while kept.len() < len && tries < len * 6 {
            tries += 1;
            let (c, p) = command(&mut r, &s);
            if s.execute(&c, &p).is_ok() {
                if c == "sketch.drag" {
                    drags += 1;
                }
                kept.push(json!({"command": c, "params": p}));
            }
        }
        std::fs::write(format!("{dir}/s{seed}.json"), serde_json::to_string(&json!({"commands": kept}))?)?;
        eprintln!("seed {seed}: {} commands, {drags} drags", kept.len());
    }
    Ok(())
}
