Test data for "Holes and cuts: leave bodies the tool cannot reach untouched without a full cut" (#10225)

generate_cases.py OUTDIR      cases next to the shortcut's edges: many far blocks with a hole
                              in a plate, tools tangent to a face / along an edge, a hair beside
                              a body, into a dome above its edge circle, at fillet rounds, a cut
                              that splits a bar, a cut extrusion and its patterns, a threaded hole
generate_background.py N KIND N background bodies (box, sheet, cthr), then a hole and threads
                              (used for g_50_sheet.json and g_50_cthr.json)

Equality, main vs branch:
  python3 generate_cases.py cases
  python3 generate_background.py 50 sheet > cases/g_50_sheet.json
  python3 generate_background.py 50 cthr > cases/g_50_cthr.json
  sh run_compare.sh <main solidcraft-cli> main
  sh run_compare.sh <branch solidcraft-cli> branch
  python3 compare_results.py main branch       results JSON (faces, edges, measurements), no timings
  python3 compare_states.py main branch        every state of the saved model cache
  python3 compare_states.py main branch history   the same, leaving each body's build history out
  cmp main/<case>.stl branch/<case>.stl, the same for .step

Timing:
  sh measure.sh <main solidcraft-cli> <branch solidcraft-cli>
  python3 summarize.py main branch
