#!/usr/bin/env python3
"""Append model.faces and model.edges for every body the eval measurement lists."""
import json
import sys

script = json.load(open(sys.argv[1]))
try:
    m = json.load(open(sys.argv[2]))
except Exception:
    m = {}
seen = []
for b in m.get("bodies", []):
    if isinstance(b, dict) and isinstance(b.get("name"), str) and b["name"] not in seen:
        seen.append(b["name"])
for n in seen:
    script["commands"].append({"command": "model.faces", "params": {"body": n}})
    script["commands"].append({"command": "model.edges", "params": {"body": n}})
json.dump(script, sys.stdout, indent=1)
