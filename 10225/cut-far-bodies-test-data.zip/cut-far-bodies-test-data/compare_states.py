#!/usr/bin/env python3
"""Usage: compare_states.py A B [entries to leave out, e.g. history]
The state after every feature from the model cache of each .sc: every body with its name,
key, feature, face names and its stored geometry. Compares two output dirs."""
import json, zipfile, sys, os, hashlib
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import scbrep
DROP = tuple(sys.argv[3].split(",")) if len(sys.argv) > 3 and sys.argv[3] else ()
def geom(parts):
    vals = [scbrep.strip(scbrep.parse(p)[0], DROP) for p in parts]
    return hashlib.sha256(json.dumps(vals, sort_keys=True, default=lambda x: x.hex()).encode()).hexdigest()[:16]
def states(path):
    z = zipfile.ZipFile(path)
    m = json.loads(z.read("cache/model.json")); blob = z.read("cache/bodies.bin")
    mod = m["model"]
    geo = [geom([blob[s:s + n] for s, n in [m["slices"][i] for i in idx]]) for idx in m["bodies"]]
    out = []
    for st in mod["states"]:
        bodies = []
        for mb_i, _ in st["bodies"] if st["bodies"] and isinstance(st["bodies"][0], list) else []:
            pass
        # states[].bodies: [[start, count], ...] ranges of model_bodies
        for start, count in st["bodies"]:
            for mb in mod["model_bodies"][start:start + count]:
                names = mod["names"][mb["names"]] if isinstance(mb.get("names"), int) else mb.get("names")
                bodies.append({"name": mb["name"], "key": mb["key"], "feature": mb["feature"], "component": mb["component"],
                               "names": names, "geometry": geo[mb["body"]]})
        out.append({k: v for k, v in st.items() if k != "bodies"} | {"bodies": bodies})
    return out
a, b = sys.argv[1], sys.argv[2]
total = bad = 0
for f in sorted(os.listdir(a)):
    if not f.endswith(".sc"): continue
    sa, sb = states(os.path.join(a, f)), states(os.path.join(b, f))
    same = sa == sb
    total += 1; bad += not same
    detail = ""
    if not same:
        for i, (x, y) in enumerate(zip(sa, sb)):
            if x != y:
                for bx, by in zip(x["bodies"], y["bodies"]):
                    if bx != by:
                        diffk = [k for k in bx if bx[k] != by.get(k)]
                        detail = f"state {i} body {bx['name']}: {diffk}"; break
                if not detail: detail = f"state {i}: {[k for k in x if x[k] != y.get(k)]}"
                break
    print(("same   " if same else "DIFFERS ") + f, detail)
print(f"{total} designs, {bad} with a state that differs")
