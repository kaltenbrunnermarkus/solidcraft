#!/usr/bin/env python3
"""Designs with N background features, then the thread and hole commands at the end.

    python3 generate_background.py N KIND > g_N_KIND.json

KIND:
  box    N separate blocks (N bodies)
  sheet  N sheet metal parts (base flange + edge flange, 2 features each)
  cthr   N cylinders with a cosmetic thread (N bodies, N threads in the model state)
At the end (always the same): a cylinder with a cosmetic thread, a plate with an M6 threaded hole,
a cylinder with a modeled thread.
"""
import json
import sys

n, art = int(sys.argv[1]), sys.argv[2]
c = []
if art == "sheet":
    c.append({"command": "sheet.manage_rules", "params": {"name": "AL2", "thickness": "2 mm", "k_factor": "0.5", "bend_radius": "1 mm", "active": True}})
for i in range(n):
    x = 200 * i
    if art == "box":
        c.append({"command": "solid.box", "params": {"corner": [x, 0, 0], "length": 50, "width": 40, "height": 30}})
    elif art == "sheet":
        c += [
            {"command": "sketch.create", "params": {"plane": "XY", "name": f"Base{i}"}},
            {"command": "sketch.rectangle.two_point", "params": {"p0": [x, 0], "p1": [x + 150, 100]}},
            {"command": "sketch.finish", "params": {}},
            {"command": "sheet.flange", "params": {"sketch": f"Base{i}"}},
            {"command": "sheet.flange", "params": {"edges": [[x + 75, 0, 2]], "height": 20}},
        ]
    elif art == "cthr":
        xx = 10 * i
        c += [
            {"command": "solid.cylinder", "params": {"radius": 3, "height": 6, "base": [xx, 500, 0]}},
            {"command": "solid.thread", "params": {"face": [xx + 3, 500, 2], "designation": "M6", "length": 4}},
        ]
    elif art != "none":
        sys.exit(f"unknown kind {art}")
# The thread commands at the end, far from the rest.
Y = -1000
c += [
    {"command": "solid.cylinder", "params": {"radius": 3, "height": 10, "base": [0, Y, 0]}},
    {"command": "solid.thread", "params": {"face": [3, Y, 5], "designation": "M6", "length": 8}},
    {"command": "solid.box", "params": {"corner": [100, Y - 30, 0], "length": 60, "width": 60, "height": 12, "body_name": "Plate"}},
    {"command": "solid.hole", "params": {"position": [130, Y, 12], "direction": [0, 0, -1], "thread": "M6", "depth": 10}},
    {"command": "solid.cylinder", "params": {"radius": 4, "height": 12, "base": [300, Y, 0]}},
    {"command": "solid.thread", "params": {"face": [304, Y, 6], "designation": "M8", "length": 8, "modeled": True}},
]
json.dump({"description": f"{n} x {art}, then threads (generated)", "commands": c}, sys.stdout, indent=1)
