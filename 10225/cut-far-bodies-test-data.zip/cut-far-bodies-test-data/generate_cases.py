#!/usr/bin/env python3
"""Test designs for "a cut leaves bodies it cannot reach untouched" (#10225).

    python3 gen_cases.py OUTDIR

Writes one script per case into OUTDIR. Each case puts cut tools (holes, cut primitives,
cut extrusions, patterns) next to bodies they touch, graze or miss by a hair, so the
result of a build with and without the shortcut can be compared byte for byte.
"""
import json
import os
import sys

out = sys.argv[1]
os.makedirs(out, exist_ok=True)


def box(corner, l, w, h, name=None, op=None, targets=None):
    p = {"corner": corner, "length": l, "width": w, "height": h}
    if name:
        p["body_name"] = name
    if op:
        p["operation"] = op
    if targets:
        p["targets"] = targets
    return {"command": "solid.box", "params": p}


def cyl(base, r, h, op=None, axis=None, name=None):
    p = {"base": base, "radius": r, "height": h}
    if op:
        p["operation"] = op
    if axis:
        p["axis"] = axis
    if name:
        p["body_name"] = name
    return {"command": "solid.cylinder", "params": p}


def hole(pos, d=6, depth=None, thread=None, direction=(0, 0, -1)):
    p = {"position": pos, "direction": list(direction), "diameter": d}
    if depth is not None:
        p["depth"] = depth
    if thread:
        p["thread"] = thread
    return {"command": "solid.hole", "params": p}


def write(name, desc, cmds):
    with open(os.path.join(out, f"{name}.json"), "w") as f:
        json.dump({"description": desc, "commands": cmds}, f, indent=1)


def boxes(n, dx=200, y=0):
    return [box([dx * i, y, 0], 50, 40, 30, name=f"Block{i}") for i in range(n)]


# Many far bodies, one hole in a plate (the measured case).
for n in (0, 50, 200):
    write(f"far_{n}_boxes", f"{n} far boxes, a plate, a hole in it",
          boxes(n) + [box([0, -1000, 0], 60, 60, 12, name="Plate"), hole([30, -970, 12], depth=10)])

# The tool touches a body only along a face or a line: the cut must still run as before.
write("tangent", "tools touching bodies on a face, along a line, at a corner", [
    box([0, 0, 0], 50, 40, 30, name="A"),
    box([100, 0, 0], 50, 40, 30, name="B"),
    box([200, 0, 0], 50, 40, 30, name="C"),
    box([300, 0, 0], 50, 40, 30, name="Far"),
    # Cylinder side tangent to A's face x = 50.
    cyl([53, 20, 0], 3, 30, op="cut"),
    # Box flush against B's face x = 150 (shares the face, no overlap).
    box([150, 0, 0], 10, 40, 30, op="cut"),
    # Box meeting C only at its top edge line.
    box([250, 0, 30], 10, 40, 10, op="cut"),
])

# A dome curves out beyond its edges: a tool into the dome's top, above its edge circle.
write("dome", "hole and cut into a dome that bulges past its edges", [
    {"command": "solid.sphere", "params": {"center": [0, 0, -10], "radius": 20, "body_name": "Dome"}},
    box([-30, -30, -40], 60, 60, 40, op="cut"),
    box([500, 0, 0], 20, 20, 20, name="Far"),
    hole([5, 5, 8.7], d=4, depth=3),
    cyl([-8, 0, 7], 1.5, 10, op="cut"),
    # A tool just over the dome's apex, 0.002 mm clear of it.
    cyl([0, 0, 10.002], 2, 5, op="cut"),
])

# Rounded edges reach out to their faces; tools grazing them.
write("rounded", "cuts at the rounds of a filleted block", [
    box([0, 0, 0], 40, 30, 20, name="Round"),
    {"command": "solid.fillet", "params": {"edges": [[20, 0, 20], [40, 15, 20]], "radius": 5}},
    box([200, 0, 0], 40, 30, 20, name="Far"),
    cyl([20, -3, 0], 3, 30, op="cut"),
    cyl([43.001, 15, 0], 3, 30, op="cut"),
])

# Tools just next to bodies: a hair's breadth clear, 0.5 mm clear, a hair inside.
write("near", "tools just beside bodies", [
    box([0, 0, 0], 50, 40, 30, name="A"),
    box([100, 0, 0], 50, 40, 30, name="B"),
    box([200, 0, 0], 50, 40, 30, name="C"),
    cyl([53.0005, 20, 0], 3, 30, op="cut"),
    cyl([153.5, 20, 0], 3, 30, op="cut"),
    cyl([252.999, 20, 0], 3, 30, op="cut"),
])

# A cut extrusion and a pattern of it across a row of plates, plus far bodies.
row = [box([70 * i, 0, 0], 50, 50, 8, name=f"Plate{i}") for i in range(6)]
write("pattern", "a cut and a pattern of it across a row of plates", row + boxes(10, y=500) + [
    {"command": "sketch.create", "params": {"plane": "XY", "name": "HoleSk"}},
    {"command": "sketch.circle.center", "params": {"center": [25, 25], "radius": 5, "id": "c1"}},
    {"command": "sketch.finish", "params": {}},
    {"command": "solid.extrude", "params": {"sketch": "HoleSk", "through_all": True, "operation": "cut", "name": "HoleCut"}},
    {"command": "solid.pattern.rectangular", "params": {"features": ["HoleCut"], "dir1": [1, 0, 0], "count1": 6, "spacing1": 70, "name": "Row"}},
    hole([25, 10, 8], d=3, depth=4),
    {"command": "solid.pattern.rectangular", "params": {"features": ["Hole1"], "dir1": [1, 0, 0], "count1": 3, "spacing1": 70}},
])

# A cut that splits one body into pieces, next to far bodies (names of the pieces).
write("split", "a cut that splits a bar, far bodies beside it", boxes(5, y=300) + [
    box([0, 0, 0], 100, 10, 10, name="Bar"),
    box([45, -5, -5], 10, 20, 20, op="cut"),
])

# A hole with a cosmetic thread among far bodies.
write("thread_hole", "threaded hole among far bodies", boxes(20) + [
    box([0, -1000, 0], 60, 60, 12, name="Plate"),
    hole([30, -970, 12], depth=10, thread="M6"),
])
