#!/bin/sh
# Time each case three times with --profile, alternating the two binaries.
# Usage: measure.sh <solidcraft-cli main> <solidcraft-cli branch>; raw runs in raw-main/, raw-branch/,
# the load average before each run in load.txt.
MAIN=$1; BRANCH=$2
mkdir -p raw-main raw-branch
for d in far_0_boxes far_50_boxes far_200_boxes g_50_sheet g_50_cthr pattern; do
  for r in 1 2 3; do
    for T in main branch; do
      [ $T = main ] && B=$MAIN || B=$BRANCH
      echo "$(date +%T) $T $d run $r load=$(cut -d' ' -f1 /proc/loadavg)" >> load.txt
      nice $B run cases/$d.json --profile --quiet > raw-$T/${d}_$r.json 2> raw-$T/${d}_$r.err
    done
  done
done
