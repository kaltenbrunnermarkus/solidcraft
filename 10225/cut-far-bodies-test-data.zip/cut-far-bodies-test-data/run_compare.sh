#!/bin/sh
# Build every case with one solidcraft-cli binary and keep what it produces:
# the eval measurement, run --results with model.faces/model.edges of every body,
# STL and STEP exports and the saved design (.sc, with its model cache).
# Usage: run_compare.sh <solidcraft-cli> <out-dir>   (cases in ./cases, see generate_cases.py)
B=$1; O=$2
mkdir -p "$O"
for f in cases/*.json; do
  n=$(basename "$f" .json)
  $B eval "$f" > "$O/$n.eval.json" 2> "$O/$n.eval.err"
  python3 add_inspect.py "$f" "$O/$n.eval.json" > "$O/$n.inspect-script.json"
  $B run "$O/$n.inspect-script.json" --results --quiet --out "$O/$n.stl" --out "$O/$n.step" --save "$O/$n.sc" > "$O/$n.results.json" 2> "$O/$n.results.err"
done
