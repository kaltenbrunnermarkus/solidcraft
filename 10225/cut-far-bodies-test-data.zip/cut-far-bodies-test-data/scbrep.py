"""A minimal reader of SCBREP04 body bytes (tagged values), to leave single entries such as the
build history out of a comparison."""
import struct
def parse(b):
    assert b[:8] == b"SCBREP04", b[:8]
    v, i = val(b, 8)
    return v, b[i:]
def u32(b, i): return struct.unpack_from("<I", b, i)[0], i + 4
def val(b, i):
    t = b[i]; i += 1
    if t == 0: return None, i
    if t == 1: return True, i
    if t == 2: return False, i
    if t == 3: return struct.unpack_from("<q", b, i)[0], i + 8
    if t == 4: return struct.unpack_from("<Q", b, i)[0], i + 8
    if t == 5: return struct.unpack_from("<d", b, i)[0], i + 8
    if t == 6:
        n, i = u32(b, i); return b[i:i + n].decode(), i + n
    if t == 7:
        n, i = u32(b, i); out = []
        for _ in range(n):
            x, i = val(b, i); out.append(x)
        return out, i
    if t == 8:
        n, i = u32(b, i); out = {}
        for _ in range(n):
            k, i = u32(b, i); key = b[i:i + k].decode(); i += k
            x, i = val(b, i); out[key] = x
        return out, i
    if t == 9:
        n, i = u32(b, i); return b[i:i + n], i + n
    raise ValueError(f"tag {t} at {i-1}")
def strip(v, drop=("history",)):
    if isinstance(v, dict): return {k: strip(x, drop) for k, x in v.items() if k not in drop}
    if isinstance(v, list): return [strip(x, drop) for x in v]
    return v
