#!/usr/bin/env python3
"""Median (min-max) over the runs: the whole script, and each solid.hole command."""
import glob, json, statistics as st, sys
for d in ["far_0_boxes", "far_50_boxes", "far_200_boxes", "g_50_sheet", "g_50_cthr", "pattern"]:
    out = [d]
    for tag in sys.argv[1:] or ["main", "branch"]:
        runs = [json.load(open(f)) for f in sorted(glob.glob(f"raw-{tag}/{d}_*.json"))]
        if not runs:
            continue
        tot = [r["total_ms"] for r in runs]
        holes = [i for i, t in enumerate(runs[0]["timings"]) if t["command"] == "solid.hole"]
        h = " ".join(f"{st.median(r['timings'][i]['ms'] for r in runs):.1f}" for i in holes)
        out.append(f"{tag}: total {st.median(tot):.0f} ({min(tot):.0f}-{max(tot):.0f}) ms, hole [{h}] ms")
    print("  ".join(out))
