Test data for "Sheet metal: a hole leaves sheet parts it cannot reach untouched" (#10226)

generate_cases.py OUTDIR      cases next to the shortcut's edges, each among far sheet parts:
                              a hole in a plate beside 0/50/200 sheet parts, a threaded hole,
                              holes through a base, into a base rim and a flange rim, holes
                              tangent to / a hair beside / a hair inside a sheet's rim, a row of
                              holes on a sheet, primitive and extrusion cuts at and beside
                              sheets, and two holes a sheet refuses (into a bend, at an angle)
generate_background.py N KIND N background bodies (box, sheet, cthr), then a hole and threads
                              (used for g_50_sheet.json)

Equality, base vs branch:
  python3 generate_cases.py cases
  python3 generate_background.py 50 sheet > cases/g_50_sheet.json
  sh run_compare.sh <base solidcraft-cli> base
  sh run_compare.sh <branch solidcraft-cli> branch
  python3 compare_results.py base branch       results JSON (faces, edges, measurements), no timings
  python3 compare_states.py base branch        every state of the saved model cache
  python3 compare_states.py base branch history   the same, leaving each body's build history out
  cmp base/<case>.stl branch/<case>.stl, the same for .step

Timing:
  sh measure.sh <base solidcraft-cli> <branch solidcraft-cli>
  python3 summarize.py base branch
