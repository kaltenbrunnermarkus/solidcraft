#!/usr/bin/env python3
"""Compare the results JSON (run --results with model.faces/model.edges of every body) and the
eval measurement of two output dirs, without timings; lists every path that differs."""
import json, os, sys
DROP = {"ms", "total_ms", "build", "evaluation"}
def norm(v):
    if isinstance(v, dict): return {k: norm(x) for k, x in v.items() if k not in DROP}
    if isinstance(v, list): return [norm(x) for x in v]
    return v
def diff(a, b, path, out):
    if type(a) != type(b): out.append(f"{path}: {str(a)[:120]} | {str(b)[:120]}"); return
    if isinstance(a, dict):
        for k in sorted(set(a) | set(b)):
            if k not in a or k not in b: out.append(f"{path}/{k}: missing"); continue
            diff(a[k], b[k], f"{path}/{k}", out)
    elif isinstance(a, list):
        if len(a) != len(b): out.append(f"{path}: {a} | {b}"); return
        for i, (x, y) in enumerate(zip(a, b)): diff(x, y, f"{path}[{i}]", out)
    elif a != b: out.append(f"{path}: {str(a)[:120]} | {str(b)[:120]}")
A, B = sys.argv[1], sys.argv[2]
for f in sorted(os.listdir(A)):
    if not (f.endswith(".results.json") or f.endswith(".eval.json")): continue
    out = []
    ta, tb = open(os.path.join(A, f)).read(), open(os.path.join(B, f)).read()
    if not ta.strip() or not tb.strip():
        # A script that stops at a refused step writes nothing: compare the text (and its .err).
        if ta != tb: out.append("one of them is empty")
    else:
        diff(norm(json.loads(ta)), norm(json.loads(tb)), "", out)
    print(("same   " if not out else "DIFFERS ") + f)
    for l in out: print("    " + l)
