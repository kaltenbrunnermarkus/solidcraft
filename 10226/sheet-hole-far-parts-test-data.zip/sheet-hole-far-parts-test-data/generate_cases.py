#!/usr/bin/env python3
"""Test designs for "a hole leaves sheet parts it cannot reach untouched" (#10226).

    python3 generate_cases.py OUTDIR

Writes one script per case into OUTDIR. Each case puts holes and cuts next to sheet metal
parts they drill, graze or miss by a hair, among sheet parts far off, so the result of a build
with and without the shortcut can be compared byte for byte.
"""
import json
import os
import sys

out = sys.argv[1]
os.makedirs(out, exist_ok=True)

RULE = {"command": "sheet.manage_rules", "params": {"name": "AL2", "thickness": "2 mm", "k_factor": "0.5", "bend_radius": "1 mm", "active": True}}
T = 2.0


def sheet(name, x, y, w, h, flange_edge=None, height=20):
    """A base flange on the rectangle (x, y)-(x+w, y+h) on XY, optionally an edge flange."""
    c = [
        {"command": "sketch.create", "params": {"plane": "XY", "name": name}},
        {"command": "sketch.rectangle.two_point", "params": {"p0": [x, y], "p1": [x + w, y + h]}},
        {"command": "sketch.finish", "params": {}},
        {"command": "sheet.flange", "params": {"sketch": name}},
    ]
    if flange_edge:
        c.append({"command": "sheet.flange", "params": {"edges": [flange_edge], "height": height}})
    return c


def far_sheets(n, y=0):
    """N L-shaped sheet parts (150 x 100 base, 20 mm flange), 200 mm apart along X."""
    c = []
    for i in range(n):
        x = 200 * i
        c += sheet(f"Far{i}", x, y, 150, 100, flange_edge=[x + 75, y, T])
    return c


def box(corner, l, w, h, name=None, op=None):
    p = {"corner": corner, "length": l, "width": w, "height": h}
    if name:
        p["body_name"] = name
    if op:
        p["operation"] = op
    return {"command": "solid.box", "params": p}


def cyl(base, r, h, op=None, axis=None):
    p = {"base": base, "radius": r, "height": h}
    if op:
        p["operation"] = op
    if axis:
        p["axis"] = axis
    return {"command": "solid.cylinder", "params": p}


def hole(pos, d=6, depth=None, thread=None, direction=(0, 0, -1)):
    p = {"position": pos, "direction": list(direction), "diameter": d}
    if depth is not None:
        p["depth"] = depth
    if thread:
        p["thread"] = thread
    return {"command": "solid.hole", "params": p}


def write(name, desc, cmds):
    with open(os.path.join(out, f"{name}.json"), "w") as f:
        json.dump({"description": desc, "commands": [RULE] + cmds}, f, indent=1)


# Many far sheet parts, one hole in a plate (the measured case).
for n in (0, 50, 200):
    write(f"far_{n}_sheets", f"{n} far sheet parts, a plate, a hole in it",
          far_sheets(n) + [box([0, -1000, 0], 60, 60, 12, name="Plate"), hole([30, -970, 12], depth=10)])

# The same with a threaded hole (its tapped wall search is not part of this change).
write("far_sheets_thread", "a threaded hole in a plate among far sheet parts",
      far_sheets(10) + [box([0, -1000, 0], 60, 60, 12, name="Plate"), hole([30, -970, 12], depth=10, thread="M6")])

# Holes into a sheet: through its base (a cut-out), into its base's rim (a bore), into its
# flange's rim, among far sheet parts.
write("sheet_holes", "holes through a base, into a base rim and a flange rim, far parts beside",
      sheet("Near", 0, -400, 60, 40, flange_edge=[30, -360, T], height=30) + far_sheets(6) + [
          hole([20, -390, T], d=6),
          hole([60, -385, T / 2], d=1.2, direction=(-1, 0, 0)),
          hole([60, -360 - T / 2, 15], d=1.0, direction=(-1, 0, 0)),
      ])

# Holes just beside a sheet, drilled into a plate next to it: tangent to the sheet's rim
# (x = 100), a hair clear, 1 mm clear, a hair inside.
write("sheet_near_holes", "holes just beside a sheet's rim, far parts beside",
      sheet("Near", 0, -400, 100, 50) + far_sheets(4) + [
          box([101, -400, 0], 40, 50, 2, name="Beside"),
          hole([103, -390, T], d=6, depth=2),
          hole([103.0005, -380, T], d=6, depth=2),
          hole([104, -370, T], d=6, depth=2),
          hole([102.999, -360, T], d=6, depth=2),
      ])

# A row of holes on a sheet from one sketch of points (one pass for all of them), far parts
# beside; and a pattern of a hole on a sheet (refused the same way by both).
points = [{"command": "sketch.point", "params": {"point": [15 + 22 * k, -380]}} for k in range(5)]
write("sheet_hole_row", "one hole feature at five sketch points on a sheet, far parts beside",
      sheet("Near", 0, -400, 120, 40) + far_sheets(4) + [
          {"command": "sketch.create", "params": {"plane": "XY", "name": "HolePoints"}},
          *points,
          {"command": "sketch.finish", "params": {}},
          {"command": "solid.hole", "params": {"sketch": "HolePoints", "diameter": 5}},
      ])
write("sheet_hole_pattern", "a rectangular pattern of a hole on a sheet, far parts beside",
      sheet("Near", 0, -400, 120, 40) + far_sheets(4) + [
          hole([15, -380, T], d=5),
          {"command": "solid.pattern.rectangular", "params": {"features": ["Hole1"], "dir1": [1, 0, 0], "count1": 5, "spacing1": 22}},
      ])

# Cuts that are no holes: a cylinder through a block next to sheets, a box grazing a sheet's
# rim, a cylinder through a sheet, an extrusion cut through one sheet and past others.
write("sheet_cuts", "primitive and extrusion cuts at and beside sheets, far parts beside",
      sheet("Near", 0, -400, 80, 40) + far_sheets(4) + [
          box([0, -600, 0], 60, 60, 12, name="Block"),
          cyl([30, -570, -1], 4, 20, op="cut"),
          box([80, -400, 0], 10, 40, 5, op="cut"),
          cyl([20, -380, -1], 3, 5, op="cut"),
          {"command": "sketch.create", "params": {"plane": "XY", "name": "Slot"}},
          {"command": "sketch.circle.center", "params": {"center": [60, -380], "radius": 4}},
          {"command": "sketch.finish", "params": {}},
          {"command": "solid.extrude", "params": {"sketch": "Slot", "through_all": True, "direction": "symmetric", "operation": "cut"}},
      ])

# Holes a sheet refuses (into its rim toward a bend; across a panel at an angle): the same
# error, nothing changed, with far parts beside.
write("sheet_refused_bend", "a rim hole that would run into a bend, far parts beside",
      sheet("Near", 0, -400, 60, 40, flange_edge=[30, -360, T], height=30) + far_sheets(3) + [
          hole([30, -400, T / 2], d=1.2, direction=(0, 1, 0)),
      ])
write("sheet_refused_angle", "a hole across a sheet at an angle, far parts beside",
      sheet("Near", 0, -400, 60, 40) + far_sheets(3) + [
          hole([30, -380, T], d=4, direction=(0.5, 0, -1)),
      ])
