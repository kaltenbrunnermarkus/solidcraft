#!/bin/sh
# Time each case three times with --profile, alternating the two binaries.
# Usage: measure.sh <solidcraft-cli base> <solidcraft-cli branch>; raw runs in raw-base/, raw-branch/,
# the load average before each run in load.txt.
BASE=$1; BRANCH=$2
mkdir -p raw-base raw-branch
for d in far_0_sheets far_50_sheets far_200_sheets g_50_sheet sheet_holes sheet_cuts; do
  for r in 1 2 3; do
    for T in base branch; do
      [ $T = base ] && B=$BASE || B=$BRANCH
      echo "$(date +%T) $T $d run $r load=$(cut -d' ' -f1 /proc/loadavg)" >> load.txt
      nice $B run cases/$d.json --profile --quiet > raw-$T/${d}_$r.json 2> raw-$T/${d}_$r.err
    done
  done
done
