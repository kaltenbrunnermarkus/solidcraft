Test designs for #10227 (tap markings among many bodies).

  python3 gen_groesse.py N KIND > g_N_KIND.json     KIND: box | sheet | cthr | none
    box   N separate boxes
    sheet N sheet-metal parts
    cthr  N cylinders, each with a cosmetic M6 tap marking
  Every design ends with: cylinder + cosmetic marking, plate + tapped M6 hole, cylinder + modelled thread.

  solidcraft-cli run g_200_cthr.json --profile --quiet      per-command timings
  mess.sh BIN LABEL     3 timed runs per design plus one run saving results, .sc, STEP and STL
  auswert.py LABEL...   medians;  gleich.py   compares base/neu results (timings left out) and .sc entries
(The scripts carry the local paths they were run from; adjust the cd line.)
