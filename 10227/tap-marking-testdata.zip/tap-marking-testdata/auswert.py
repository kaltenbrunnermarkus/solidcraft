import json,glob,statistics as st
for d in ["g_0_box","g_200_box","g_50_cthr","g_200_cthr"]:
    out=[d]
    for L in ["base","neu"]:
        runs=[json.load(open(f)) for f in sorted(glob.glob(f"roh/{L}/{d}_*.json"))]
        if not runs: continue
        tot=[r["total_ms"] for r in runs]
        thr=[sum(t["ms"] for t in r["timings"] if t["command"]=="solid.thread") for r in runs]
        hole=[sum(t["ms"] for t in r["timings"] if t["command"]=="solid.hole") for r in runs]
        out.append(f"{L}: total {st.median(tot):.0f} ms ({'/'.join(f'{x:.0f}' for x in tot)}), thread-Summe {st.median(thr):.0f}, hole {st.median(hole):.1f}")
    print("  |  ".join(out))
