#!/usr/bin/env python3
"""Testdesigns für die Gewinde-Messung: N Hintergrund-Features, danach die Gewinde-Befehle.

    python3 gen_groesse.py N ART > groesse_N_ART.json

ART:
  box    N eigenständige Quader (N Körper)
  sheet  N Blechteile (Grundlasche + Kantenlasche, 2 Features je Teil)
  cthr   N Zylinder mit kosmetischem Gewinde (N Körper, N Gewinde im ModelState)
Am Ende (immer gleich): Platte, Zylinder + kosmetisches Gewinde, Bohrung M6 mit Gewinde,
Zylinder + modelliertes Gewinde.
"""
import json
import sys

n, art = int(sys.argv[1]), sys.argv[2]
c = []
if art == "sheet":
    c.append({"command": "sheet.manage_rules", "params": {"name": "AL2", "thickness": "2 mm", "k_factor": "0.5", "bend_radius": "1 mm", "active": True}})
for i in range(n):
    x = 200 * i
    if art == "box":
        c.append({"command": "solid.box", "params": {"corner": [x, 0, 0], "length": 50, "width": 40, "height": 30}})
    elif art == "sheet":
        c += [
            {"command": "sketch.create", "params": {"plane": "XY", "name": f"Base{i}"}},
            {"command": "sketch.rectangle.two_point", "params": {"p0": [x, 0], "p1": [x + 150, 100]}},
            {"command": "sketch.finish", "params": {}},
            {"command": "sheet.flange", "params": {"sketch": f"Base{i}"}},
            {"command": "sheet.flange", "params": {"edges": [[x + 75, 0, 2]], "height": 20}},
        ]
    elif art == "cthr":
        xx = 10 * i
        c += [
            {"command": "solid.cylinder", "params": {"radius": 3, "height": 6, "base": [xx, 500, 0]}},
            {"command": "solid.thread", "params": {"face": [xx + 3, 500, 2], "designation": "M6", "length": 4}},
        ]
    elif art != "none":
        sys.exit(f"unbekannte Art {art}")
# Gewinde-Befehle am Ende, weit weg vom Rest.
Y = -1000
c += [
    {"command": "solid.cylinder", "params": {"radius": 3, "height": 10, "base": [0, Y, 0]}},
    {"command": "solid.thread", "params": {"face": [3, Y, 5], "designation": "M6", "length": 8}},
    {"command": "solid.box", "params": {"corner": [100, Y - 30, 0], "length": 60, "width": 60, "height": 12, "body_name": "Platte"}},
    {"command": "solid.hole", "params": {"position": [130, Y, 12], "direction": [0, 0, -1], "thread": "M6", "depth": 10}},
    {"command": "solid.cylinder", "params": {"radius": 4, "height": 12, "base": [300, Y, 0]}},
    {"command": "solid.thread", "params": {"face": [304, Y, 6], "designation": "M8", "length": 8, "modeled": True}},
]
json.dump({"description": f"{n} x {art}, danach Gewinde (generiert)", "commands": c}, sys.stdout, indent=1)
