"""Vergleicht base/neu: JSON ohne Zeitfelder, .sc-Archive Eintrag für Eintrag."""
import json,sys,zipfile
TIME={"ms","total_ms","timings","elapsed_ms","duration_ms"}
def strip(x):
    if isinstance(x,dict): return {k:strip(v) for k,v in x.items() if k not in TIME}
    if isinstance(x,list): return [strip(v) for v in x]
    return x
for d in ["g_0_box","g_200_box","g_50_cthr","g_200_cthr"]:
    for x in ["results.json","eval.json"]:
        a,b=[strip(json.load(open(f"gleich/{L}/{d}.{x}"))) for L in ("base","neu")]
        print(d,x,"gleich" if a==b else "VERSCHIEDEN")
    za,zb=[zipfile.ZipFile(f"gleich/{L}/{d}.sc") for L in ("base","neu")]
    na,nb=sorted(za.namelist()),sorted(zb.namelist())
    if na!=nb: print(d,"sc Einträge verschieden",set(na)^set(nb)); continue
    diff=[n for n in na if za.read(n)!=zb.read(n)]
    print(d,"sc", "gleich" if not diff else f"verschieden in {diff}")
