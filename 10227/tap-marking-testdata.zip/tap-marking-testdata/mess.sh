#!/bin/sh
# Misst jedes Design 3x mit --profile (BIN = $1, Name = $2); dazu ein Lauf mit Ergebnissen und Exporten zum Vergleich.
cd /home/markus/solidcraft-p6/out/10227 || exit 1
B=$1; L=$2
mkdir -p roh/$L gleich/$L
for d in g_0_box g_200_box g_50_cthr g_200_cthr; do
  for r in 1 2 3; do
    echo "$(date +%T) $L $d lauf $r last=$(cut -d' ' -f1 /proc/loadavg)" >> mess.last
    $B run $d.json --profile --quiet > roh/$L/${d}_$r.json 2> roh/$L/${d}_$r.err
  done
  $B run $d.json --results --quiet --json-out gleich/$L/$d.results.json --save gleich/$L/$d.sc --out gleich/$L/$d.step --out gleich/$L/$d.stl > gleich/$L/$d.out 2> gleich/$L/$d.err
  $B eval gleich/$L/$d.sc --json-out gleich/$L/$d.eval.json > /dev/null 2>> gleich/$L/$d.err
done
touch mess-$L.FERTIG
