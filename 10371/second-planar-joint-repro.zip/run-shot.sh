# usage: run-shot.sh <app-binary> <port> <out-prefix> <display> <red-top-point-json>
# Own data folders under out/, software GPU; everything bounded by timeout.
APP=$1; PORT=$2; OUT=$3; D=$4; RED=$5
H=$PWD/out/10331/home-$D
mkdir -p $H/data $H/config $H/cache
export XDG_DATA_HOME=$H/data XDG_CONFIG_HOME=$H/config XDG_CACHE_HOME=$H/cache LANG=en_US.UTF-8 LC_ALL=en_US.UTF-8
export SOLIDCRAFT_CONTROL_TOKEN=$(openssl rand -hex 32) SOLIDCRAFT_GPU=software WGPU_BACKEND=vulkan VK_DRIVER_FILES=/usr/share/vulkan/icd.d/lvp_icd.json
timeout 200 Xvfb :$D -screen 0 1600x1000x24 > out/10331/xvfb-$D.log 2>&1 &
sleep 2
DISPLAY=:$D timeout 195 kwin_x11 > out/10331/kwin-$D.log 2>&1 &
sleep 4
DISPLAY=:$D timeout 190 $APP --control $PORT > out/10331/app-$D.log 2>&1 &
timeout 180 python3 out/10331/shot.py $PORT $OUT "$RED" 2>&1 | cut -c1-400
