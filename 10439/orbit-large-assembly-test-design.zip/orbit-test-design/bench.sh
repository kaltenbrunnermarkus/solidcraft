#!/bin/bash
# bench.sh: the orbit measurement, main and fix binaries alternating, 3 runs each per design.
cd /home/markus/solidcraft-p2
D=$PWD/out/orbit/design
for d in "SOLIDCRAFT_SCALE_DESIGN=$D/featured.solidcraft" "SOLIDCRAFT_SCALE_DESIGN=$D/big.solidcraft" "SOLIDCRAFT_SCALE_STEP=$D/big.step"; do
  for r in 1 2 3; do
    for b in base fix; do
      out/orbit/run.sh $b bench $d SOLIDCRAFT_SCALE_LOOP=60 WGPU_BACKEND=metal
    done
  done
done
date > out/orbit/bench.FERTIG
