#!/usr/bin/env python3
"""Write a SolidCraft command script: a large nested assembly of repeated parts.

    python3 big_assembly.py MODULES_X MODULES_Y BOLTS [BOLT_FEATURES [FRAME_FEATURES]] > big-assembly.json
    solidcraft-cli run big-assembly.json --save big-assembly.solidcraft

A "Module" sub-assembly holds a plate and a BOLTS x BOLTS grid of placed "Bolt" components (a
shaft and a head, two bodies each); the module is placed MODULES_X x MODULES_Y times on the root,
beside a few unique parts. Bodies: MODULES_X * MODULES_Y * (1 + 2 * BOLTS^2) + 4, and one more
with FRAME_FEATURES. The bolt's head takes BOLT_FEATURES - 2 small knurls joined to it (default 2:
none), and a "Frame" part on the root is a beam of FRAME_FEATURES boxes joined end to end (default
0: none), so the design's history is long, as in a design modelled feature by feature.
"""
import json
import sys

mx = int(sys.argv[1]) if len(sys.argv) > 1 else 8
my = int(sys.argv[2]) if len(sys.argv) > 2 else 8
nb = int(sys.argv[3]) if len(sys.argv) > 3 else 4
bolt_features = int(sys.argv[4]) if len(sys.argv) > 4 else 2
frame_features = int(sys.argv[5]) if len(sys.argv) > 5 else 0
pitch = 12.0
size = pitch * nb + 8
s = []
def c(cmd, **p):
    s.append({"command": cmd, "params": p})
c("component.create", name="Module", parent=0)
c("solid.box", length=size, width=size, height=4, center=[size / 2 - 4, size / 2 - 4, 2], operation="new", name="Plate")
c("component.create", name="Bolt", parent="Module")
c("solid.cylinder", base=[0, 0, 4], radius=2, height=14, operation="new", name="Shaft")
c("solid.cylinder", base=[0, 0, 18], radius=3.5, height=3, operation="new", name="Head")
knurls = max(bolt_features - 2, 0)
for k in range(knurls):
    import math
    a = 2 * math.pi * k / knurls
    c("solid.box", length=0.8, width=0.8, height=2.4, center=[3.3 * math.cos(a), 3.3 * math.sin(a), 19.5], operation="join", name=f"Knurl{k}")
c("component.activate", component="Module")
c("solid.pattern.rectangular", components=["Bolt"], dir1=[1, 0, 0], count1=nb, spacing1=pitch, dir2=[0, 1, 0], count2=nb, spacing2=pitch, name="Bolts")
c("component.activate", component=0)
c("solid.pattern.rectangular", components=["Module"], dir1=[1, 0, 0], count1=mx, spacing1=size + 10, dir2=[0, 1, 0], count2=my, spacing2=size + 10, name="Modules")
if frame_features > 0:
    c("component.create", name="Frame", parent=0)
    for k in range(frame_features):
        c("solid.box", length=6, width=4, height=4, center=[5.0 * k, -40, 2], operation="new" if k == 0 else "join", name=f"Beam{k}")
    c("component.activate", component=0)
for i in range(4):
    c("solid.torus", major=30, minor=6, center=[-60, 80.0 * i, 10], body_name=f"Ring{i}")
json.dump(s, sys.stdout, indent=1)
