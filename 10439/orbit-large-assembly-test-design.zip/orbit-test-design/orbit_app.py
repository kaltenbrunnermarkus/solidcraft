#!/usr/bin/env python3
"""Frame times while orbiting a design in a running SolidCraft (`solidcraft --control PORT`),
and a screenshot of the window.

    solidcraft --control 7921 &
    python3 orbit_app.py --port 7921 --shot out.png featured.solidcraft

Opens the design, shows it from the iso view fitted, then drags the right button (orbit) across
the view: each round is MOVES short orbit drags, each followed by `ui.inspect` `frame_ms` (the
window thread's time of the last UI frame; the control channel answers between drags only). Prints one JSON line per round: median, p90, min, max. With --shot,
the window is saved once the view rests after the last round.
"""
import argparse
import json
import os
import statistics
import sys
import time

sys.path.insert(0, os.environ.get("SOLIDCRAFT_DEMO", os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "..", "examples", "demo")))
from enclosure_mcp import control  # noqa: E402


def stats(v):
    v = sorted(v)
    if not v:
        return None
    return {"n": len(v), "median_ms": round(statistics.median(v), 3), "p90_ms": round(v[max(0, int(len(v) * 0.9) - 1)], 3),
            "min_ms": round(v[0], 3), "max_ms": round(v[-1], 3)}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("design")
    ap.add_argument("--port", type=int, default=7921)
    ap.add_argument("--rounds", type=int, default=3)
    ap.add_argument("--moves", type=int, default=40)
    ap.add_argument("--settle", type=float, default=600)
    ap.add_argument("--shot")
    a = ap.parse_args()

    def ui(method, params=None):
        r = control(a.port, method, params)
        if not r.get("ok", False):
            raise RuntimeError(f"{method}: {r.get('error')}")
        return r.get("result")

    ui("ui.resize", {"width": 1600, "height": 1000})
    ui("ui.home", {"open": False})
    ui("ui.file", {"path": os.path.abspath(a.design)})
    time.sleep(1)
    while ui("ui.inspect").get("file_busy"):
        time.sleep(0.5)
    ui("ui.home", {"open": False})
    ui("ui.set", {"showSketches": False, "showOrigin": False})
    ui("ui.view", {"view": "iso"})
    t0 = time.time()
    while True:
        r = control(a.port, "ui.camera", {"fit": True})
        if r.get("ok", False) or time.time() - t0 > a.settle:
            break
        time.sleep(1)
    t1 = time.time()
    while time.time() - t1 < a.settle and (ui("ui.inspect").get("draw") or {}).get("triangles", 0) == 0:
        time.sleep(1)
    ui("ui.camera", {"fit": True})
    time.sleep(3)
    print(json.dumps({"shown_after_s": round(time.time() - t0, 1), "draw": ui("ui.inspect").get("draw")}), flush=True)
    vx, vy, vw, vh = ui("ui.inspect")["viewport"]
    cx, cy = vx + vw * 0.5, vy + vh * 0.5
    for rnd in range(a.rounds):
        samples = []
        for i in range(a.moves):
            x = cx - 200 + 10 * (i % 40)
            ui("ui.drag", {"x0": x, "y0": cy, "x1": x + 10, "y1": cy + 2, "button": "right", "steps": 3})
            samples.append(ui("ui.inspect")["frame_ms"])
        print(json.dumps({"round": rnd, "frame_ms": stats(samples)}), flush=True)
        time.sleep(1)
    if a.shot:
        time.sleep(2)
        ui("ui.screenshot", {"path": os.path.abspath(a.shot)})
        time.sleep(2)
        print(json.dumps({"shot": a.shot}), flush=True)


if __name__ == "__main__":
    main()
