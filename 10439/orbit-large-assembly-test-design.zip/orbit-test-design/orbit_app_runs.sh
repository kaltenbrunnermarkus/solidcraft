#!/bin/bash
# orbit_app_runs.sh DESIGN ROUNDS APP_A APP_B OUTDIR: orbit_app.py on two app builds alternating
# (A B A B ...), each under its own Xvfb with kwin_x11 and the software renderer, settings in
# OUTDIR/state-RUN-BUILD; the app is quit over the control channel. The last run of each build
# saves a screenshot (OUTDIR/A.png, OUTDIR/B.png).
set -u
DESIGN=$(realpath "$1"); ROUNDS=$2; A=$(realpath "$3"); B=$(realpath "$4"); mkdir -p "$5"; OUT=$(realpath "$5")
HERE=$(cd "$(dirname "$0")" && pwd)
export SOLIDCRAFT_DEMO=/home/markus/solidcraft-p2/examples/demo
export SOLIDCRAFT_GPU=software WGPU_BACKEND=vulkan VK_DRIVER_FILES=/usr/share/vulkan/icd.d/lvp_icd.json
LOG=$OUT/runs.log
PORT=7921
for r in $(seq 1 "$ROUNDS"); do
  for v in A B; do
    BIN=$A; [ "$v" = B ] && BIN=$B
    mkdir -p "$OUT/state-$r-$v/config" "$OUT/state-$r-$v/data" "$OUT/state-$r-$v/home"
    export XDG_CONFIG_HOME=$OUT/state-$r-$v/config XDG_DATA_HOME=$OUT/state-$r-$v/data HOME=$OUT/state-$r-$v/home
    echo "run $r $v load $(cut -d' ' -f1-3 /proc/loadavg) $(date +%T)" >> "$LOG"
    timeout 900 xvfb-run -a -s "-screen 0 1920x1080x24" sh -c "kwin_x11 >/dev/null 2>&1 & sleep 2; exec '$BIN' --control $PORT" > "$OUT/app-$r-$v.log" 2>&1 &
    for i in $(seq 1 120); do
      python3 -c "import socket; socket.create_connection(('127.0.0.1', $PORT), 1)" 2>/dev/null && break
      sleep 1
    done
    sleep 2
    cp "$DESIGN" "$OUT/run-$r-$v.solidcraft"
    SHOT=()
    [ "$r" = "$ROUNDS" ] && SHOT=(--shot "$OUT/$v.png")
    timeout 800 python3 "$HERE/orbit_app.py" --port $PORT "${SHOT[@]}" "$OUT/run-$r-$v.solidcraft" 2>&1 | sed "s/^/$v $r /" >> "$LOG"
    python3 -c "
import sys; sys.path.insert(0, '$SOLIDCRAFT_DEMO')
from enclosure_mcp import control
control($PORT, 'app.quit', {'force': True})" > /dev/null 2>&1
    wait
  done
done
echo DONE >> "$LOG"
