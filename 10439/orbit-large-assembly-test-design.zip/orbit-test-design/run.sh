#!/bin/bash
# run.sh BIN LOGNAME [env assignments...]: the orbit measurement with one test binary.
cd /home/markus/solidcraft-p2
export SOLIDCRAFT_GPU=software WGPU_BACKEND=vulkan VK_DRIVER_FILES=/usr/share/vulkan/icd.d/lvp_icd.json
B=$1; N=$2; shift 2
for kv in "$@"; do export "$kv"; done
{ echo "bin $B load $(cut -d' ' -f1-3 /proc/loadavg) $(date +%T) $*"
  timeout 1800 out/bin/$B --ignored --nocapture --exact scale_tests::orbit_frame_cost 2>&1 | grep -E "ORBIT|test result|panicked|error|skipping"
} >> out/orbit/$N.log 2>&1
