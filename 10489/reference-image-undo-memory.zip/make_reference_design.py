#!/usr/bin/env python3
"""Writes a noise PNG (incompressible, about SIZE_MB) and a SolidCraft script that inserts it as a
canvas and then makes EDITS small edits (parameters), so the undo history fills up."""
import json, os, random, struct, sys, zlib

out = sys.argv[1] if len(sys.argv) > 1 else "."
size_mb = float(sys.argv[2]) if len(sys.argv) > 2 else 4.0
edits = int(sys.argv[3]) if len(sys.argv) > 3 else 250

side = int((size_mb * 1024 * 1024 / 3) ** 0.5)
rng = random.Random(10489)
raw = b"".join(b"\0" + rng.randbytes(side * 3) for _ in range(side))

def chunk(kind, data):
    return struct.pack(">I", len(data)) + kind + data + struct.pack(">I", zlib.crc32(kind + data) & 0xFFFFFFFF)

png = b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", side, side, 8, 2, 0, 0, 0)) \
    + chunk(b"IDAT", zlib.compress(raw, 1)) + chunk(b"IEND", b"")
image = os.path.join(out, "reference.png")
with open(image, "wb") as f:
    f.write(png)
commands = [{"command": "canvas.insert", "params": {"path": os.path.abspath(image), "plane": "XY", "width": 200}}]
commands += [{"command": "parameters.add", "params": {"name": f"p{i}", "expression": f"{i + 1} mm"}} for i in range(edits)]
with open(os.path.join(out, "reference_edits.json"), "w") as f:
    json.dump({"commands": commands}, f, indent=0)
print(f"{image}: {len(png)} bytes, {side}x{side}; {edits} edits")
