Test data for "Placement digests look up bodies by name once" (#10492)

python3 gen_many_bodies.py 1000 40 0 > b1000_c40.json   # 1000 boxes, 40 cuts without targets
python3 gen_many_bodies.py 200 50 0 > b200_c50.json     # 200 boxes, 50 cuts
python3 tail.py 5 > tail5.json                          # 5 small boxes, one command each

solidcraft-cli run b1000_c40.json --save b1000_c40.sc   # once, slow (each cut meets every box)
solidcraft-cli run tail5.json --in b1000_c40.sc --timings --results --save out.sc
summarize.py / same.py compare the runs of two builds (roh-base/, roh-neu/; see mess.sh).
