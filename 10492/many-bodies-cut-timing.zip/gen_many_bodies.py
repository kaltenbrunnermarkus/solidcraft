#!/usr/bin/env python3
"""Test design for "placement digests look up bodies by name once".

    python3 gen_many_bodies.py BODIES CUTS TAIL > design.json

BODIES separate boxes (one body each) in a grid, then CUTS cut cylinders without explicit
targets (each one cuts into its own box), then TAIL small far-away boxes. Every command
evaluates the whole timeline again; each cut's placement digest covers every body of its
component, so the tail commands show what one command costs once the design is large.
"""
import json
import sys

bodies, cuts, tail = (int(a) for a in sys.argv[1:4])
cols = 40
c = []
for i in range(bodies):
    x, y = 100 * (i % cols), 100 * (i // cols)
    c.append({"command": "solid.box", "params": {"corner": [x, y, 0], "length": 50, "width": 40, "height": 30}})
for k in range(cuts):
    i = (k * 7) % max(bodies, 1)
    x, y = 100 * (i % cols), 100 * (i // cols)
    c.append({"command": "solid.cylinder", "params": {"base": [x + 25, y + 20, 10], "radius": 3, "height": 30, "operation": "cut"}})
for t in range(tail):
    c.append({"command": "solid.box", "params": {"corner": [100 * t, -1000, 0], "length": 5, "width": 5, "height": 5}})
json.dump({"description": f"{bodies} boxes, {cuts} cuts without targets, {tail} more boxes", "commands": c}, sys.stdout, indent=1)
