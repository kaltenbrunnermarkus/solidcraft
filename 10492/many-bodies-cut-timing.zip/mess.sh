#!/bin/sh
# Each design 3x, main and branch alternating: 5 small boxes on top of the saved design.
# Raw data roh-<tag>/<design>_<run>.json (+ .sc of the result), load in mess.last.
cd /home/markus/solidcraft-p4/out/cutperf || exit 1
mkdir -p roh-base roh-neu
for r in 1 2 3; do
  for d in b200_c50 b1000_c40; do
    for T in base neu; do
      echo "$(date +%T) $T $d run $r load=$(cut -d' ' -f1-3 /proc/loadavg)" >> mess.last
      timeout 1500 ../bin/solidcraft-cli-$T run tail5.json --in $d.sc --timings --results --save roh-$T/${d}_$r.sc --quiet > roh-$T/${d}_$r.json 2> roh-$T/${d}_$r.err
      echo "rc=$?" >> mess.last
    done
  done
done
touch mess.FERTIG
