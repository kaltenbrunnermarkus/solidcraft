#!/usr/bin/env python3
"""Results of main and branch, without timing fields, must be equal; also the saved designs' model."""
import json, glob, os, zipfile
DROP = {"ms", "total_ms", "timings", "profile"}
def norm(v):
    if isinstance(v, dict): return {k: norm(x) for k, x in v.items() if k not in DROP}
    if isinstance(v, list): return [norm(x) for x in v]
    return v
for f in sorted(glob.glob("roh-base/*.json")):
    g = f.replace("roh-base", "roh-neu")
    if not os.path.exists(g) or not os.path.getsize(g) or not os.path.getsize(f): continue
    a, b = norm(json.load(open(f))), norm(json.load(open(g)))
    sa, sb = f[:-5] + ".sc", g[:-5] + ".sc"
    za, zb = zipfile.ZipFile(sa), zipfile.ZipFile(sb)
    diff = [n for n in za.namelist() if n not in zb.namelist() or za.read(n) != zb.read(n)]
    # The model cache records how long each feature took; everything else (keys, fingerprints) must match.
    if "cache/model.json" in diff and norm(json.loads(za.read("cache/model.json"))) == norm(json.loads(zb.read("cache/model.json"))):
        diff.remove("cache/model.json")
    print(("same   " if a == b else "DIFFER ") + os.path.basename(f), "sc entries differing:", diff)
