#!/usr/bin/env python3
"""Median (min-max) over the runs: the 5 box commands on top of each saved design."""
import glob, json, os, statistics as st
for d in ["b200_c50", "b1000_c40"]:
    out = [d]
    for tag in ["base", "neu"]:
        runs = [json.load(open(f)) for f in sorted(glob.glob(f"roh-{tag}/{d}_*.json")) if os.path.getsize(f)]
        if not runs:
            continue
        per = [st.median(t["ms"] for t in r["timings"]) for r in runs]
        tot = [r["total_ms"] for r in runs]
        out.append(f"{tag}: per command median {st.median(per):.0f} ({min(per):.0f}-{max(per):.0f}) ms, 5 commands {st.median(tot):.0f} ms, n={len(runs)}")
    print("  ".join(out))
