#!/usr/bin/env python3
"""tail.py N > tail.json: N small far-away boxes, each a command on top of a saved design."""
import json, sys
n = int(sys.argv[1])
json.dump({"description": f"{n} small boxes on top of a design", "commands": [
    {"command": "solid.box", "params": {"corner": [100 * t, -1000, 0], "length": 5, "width": 5, "height": 5}} for t in range(n)]}, sys.stdout, indent=1)
