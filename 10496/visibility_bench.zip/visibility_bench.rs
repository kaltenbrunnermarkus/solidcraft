//! Measures the viewport's visibility questions on a large design: is each sketch shown
//! (300 sketches, 3,000 features) and is each body shown (300 bodies, 150 hidden).
//! Prints the median time per pass over all sketches / bodies, and a digest of the answers.
use std::sync::Arc;
use std::time::Instant;

use serde_json::json;
use solidcraft_engine::Session;
use solidcraft_engine::view::sketch_shown;

fn main() {
    let mut s = Session::default();
    s.execute("sketch.create", &json!({"plane": "XY"})).unwrap();
    s.execute("sketch.rectangle.two_point", &json!({"p0": [0, 0], "p1": [10, 10]})).unwrap();
    s.execute("sketch.finish", &json!({})).unwrap();
    s.execute("solid.extrude", &json!({"sketch": s.doc.features[0].id, "distance": 5})).unwrap();
    s.execute("solid.box", &json!({"length": 4, "width": 4, "height": 4, "corner": [30, 0, 0], "operation": "new"})).unwrap();
    let (sketch, extrude, other) = (s.doc.features[0].clone(), s.doc.features[1].clone(), s.doc.features[2].clone());
    let mut doc = (*s.doc).clone();
    doc.features.clear();
    let mut next = 1000u64;
    let mut sketch_ids = Vec::new();
    // Blocks of 10: a sketch, its Extrude (every fifth sketch is left unused) and 8 other features.
    for i in 0..300 {
        let mut sk = sketch.clone();
        sk.id = next;
        sk.name = format!("Sketch{i}");
        next += 1;
        sketch_ids.push(sk.id);
        doc.features.push(sk.clone());
        let mut ex = if i % 5 == 4 { other.clone() } else { extrude.clone() };
        if let solidcraft_doc::FeatureKind::Extrude { sketch: r, .. } = &mut ex.kind {
            *r = sk.id.into();
        }
        ex.id = next;
        ex.name = format!("F{next}");
        next += 1;
        doc.features.push(ex);
        for _ in 0..8 {
            let mut o = other.clone();
            o.id = next;
            o.name = format!("F{next}");
            next += 1;
            doc.features.push(o);
        }
    }
    s.doc = Arc::new(doc);
    let bodies: Vec<String> = (0..300).map(|i| format!("Body{i}")).collect();
    s.visibility.hidden_bodies = bodies.iter().step_by(2).cloned().collect();
    println!("features {}, sketches {}, bodies {}, hidden {}", s.doc.features.len(), sketch_ids.len(), bodies.len(), s.visibility.hidden_bodies.len());

    let passes = 200;
    let median = |mut v: Vec<f64>| {
        v.sort_by(|a, b| a.partial_cmp(b).unwrap());
        v[v.len() / 2]
    };
    let mut digest = 0u64;
    let mut sk_times = Vec::new();
    for _ in 0..passes {
        let t = Instant::now();
        let shown = sketch_ids.iter().filter(|id| sketch_shown(&s, **id)).count();
        sk_times.push(t.elapsed().as_secs_f64() * 1e6);
        digest = digest.wrapping_mul(31).wrapping_add(shown as u64);
    }
    let mut body_times = Vec::new();
    for _ in 0..passes {
        let t = Instant::now();
        let shown = bodies.iter().filter(|b| s.body_visible(b)).count();
        body_times.push(t.elapsed().as_secs_f64() * 1e6);
        digest = digest.wrapping_mul(31).wrapping_add(shown as u64);
    }
    let shown_sketches: Vec<u64> = sketch_ids.iter().copied().filter(|id| sketch_shown(&s, *id)).collect();
    let shown_bodies: Vec<&String> = bodies.iter().filter(|b| s.body_visible(b)).collect();
    println!("sketch pass median {:.1} us", median(sk_times));
    println!("body pass median {:.1} us", median(body_times));
    println!("answers: {} sketches shown {:?}..., {} bodies shown, digest {digest}", shown_sketches.len(), &shown_sketches[..5], shown_bodies.len());
}
