#!/usr/bin/env python3
"""Write copies of a saved design whose document.json is broken but whose model cache is
signed for the broken text (so the cache key matches and the document check decides).

    python3 broken_document.py design.solidcraft OUT_PREFIX
"""
import hashlib, json, sys, zipfile

src, prefix = sys.argv[1], sys.argv[2]
with zipfile.ZipFile(src) as z:
    infos = z.infolist()
    data = {i.filename: z.read(i.filename) for i in infos}
doc = json.loads(data["document.json"])
variants = {
    "features-not-a-list": json.dumps(dict(doc, features=5), separators=(",", ":")).encode(),
    "truncated": data["document.json"][: len(data["document.json"]) // 2],
    "bad-feature": json.dumps(dict(doc, features=[{"id": 1, "kind": {"Nope": {}}}] + doc["features"][1:]), separators=(",", ":")).encode(),
}
for name, broken in variants.items():
    manifest = json.loads(data["cache/model.json"])
    manifest["document"] = hashlib.sha256(broken).hexdigest()
    out = dict(data, **{"document.json": broken, "cache/model.json": json.dumps(manifest, separators=(",", ":")).encode()})
    with zipfile.ZipFile(f"{prefix}-{name}.solidcraft", "w") as z:
        for i in infos:
            z.writestr(i, out[i.filename])
    print(f"{prefix}-{name}.solidcraft")
