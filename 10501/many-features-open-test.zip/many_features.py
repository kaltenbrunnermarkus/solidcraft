#!/usr/bin/env python3
"""Write a SolidCraft command script for a design with many features and a model cache.

    python3 many_features.py BLOCKS > many-features.json
    solidcraft-cli run many-features.json --save many-features.solidcraft
    solidcraft-cli bench-open many-features.solidcraft --parse-only

Each block is a sketch (a dimensioned rectangle and a circle) and a pad of it as its own body,
in a grid: 2 * BLOCKS features. Saving keeps the evaluated model, so opening the design reads
document.json and the model cache; the "parse" step of bench-open times exactly that.
"""
import json
import sys

blocks = int(sys.argv[1]) if len(sys.argv) > 1 else 1500
cols = 40
steps = []
for i in range(blocks):
    x, y = 100 * (i % cols), 100 * (i // cols)
    steps += [
        {"command": "sketch.create", "params": {"plane": "XY", "name": f"S{i}"}},
        {"command": "sketch.rectangle.two_point", "params": {"p0": [x, y], "p1": [x + 60, y + 40]}},
        {"command": "sketch.circle.center", "params": {"center": [x + 30, y + 20], "diameter": 10}},
        {"command": "sketch.finish", "params": {}},
        {"command": "solid.extrude", "params": {"distance": 5 + i % 7, "body_name": f"B{i}"}},
    ]
json.dump({"commands": steps}, sys.stdout, indent=1)
