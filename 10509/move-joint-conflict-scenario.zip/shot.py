# Drives a running SolidCraft over its control channel: two boards, two planar joints (#10331),
# a screenshot, then Move on the red board and a second screenshot.
import json, os, socket, sys, time
port, out, red_top = int(sys.argv[1]), sys.argv[2], json.loads(sys.argv[3])
token = os.environ["SOLIDCRAFT_CONTROL_TOKEN"]
for _ in range(240):
    try:
        s = socket.create_connection(("127.0.0.1", port)); break
    except OSError:
        time.sleep(1)
f = s.makefile("rw")
n = [0]
def call(method, params, first=False):
    n[0] += 1
    req = {"id": n[0], "method": method, "params": params}
    if first: req["token"] = token
    f.write(json.dumps(req) + "\n"); f.flush()
    while True:
        line = json.loads(f.readline())
        if line.get("id") == n[0]:
            print(method, json.dumps(line)[:400]); return line
call("ui.inspect", {}, first=True)
for c in json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "boards.json")))["commands"]:
    call("engine.execute", {"command": c["command"], "params": c["params"]})
call("engine.execute", {"command": "joint.list", "params": {}})
call("ui.view", {"view": "iso"})
call("ui.camera", {"fit": True})
def shot(path):
    for _ in range(10):
        time.sleep(3)
        if call("ui.screenshot", {"path": path}).get("ok"):
            return
shot(out + "-joined.png")
p = call("ui.worldToScreen", {"points": [red_top]})
xy = p.get("result", {}).get("points", [[0, 0]])[0] if isinstance(p.get("result"), dict) else p.get("result", [[0, 0]])[0]
sel = json.loads(sys.argv[4]) if len(sys.argv) > 4 and sys.argv[4] else None
if isinstance(sel, dict):
    call("engine.execute", {"command": "select.set", "params": sel})
    call("ui.selection", {})
else:
    call("ui.click", {"x": xy[0], "y": xy[1]})
time.sleep(1)
call("ui.start", {"command": "occurrence.move"})
time.sleep(2)
call("ui.move", {"x": 1500, "y": 760})
time.sleep(1)
call("ui.messages", {})
shot(out + "-move.png")
