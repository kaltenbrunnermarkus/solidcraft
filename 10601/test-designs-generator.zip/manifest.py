#!/usr/bin/env python3
"""manifest.py DESIGN.sc: Größe von cache/model.json, Anteil der Markierungen, behaltene Zustände."""
import json, sys, zipfile
z = zipfile.ZipFile(sys.argv[1])
if "cache/model.json" not in z.namelist():
    print(sys.argv[1], "kein Cache"); sys.exit()
raw = z.read("cache/model.json")
m = json.loads(raw)["model"]
f = m["features"]
kept = sum(1 for x in f if "state" in x)
thr_top = len(json.dumps(m.get("threads", []), separators=(",", ":")))
thr_states = sum(len(json.dumps(s.get("threads", []), separators=(",", ":"))) for s in m["states"])
print(f"{sys.argv[1]}: manifest {len(raw)/1e6:.2f} MB, states kept {kept}/{len(f)}, markings table {thr_top/1e6:.3f} MB, in states {thr_states/1e6:.3f} MB")
