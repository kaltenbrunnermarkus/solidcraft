#!/bin/bash
# mess.sh: Basis und Branch abwechselnd, 3 Läufe je Design: Speichern mit Cache (bench-open --save),
# Manifest auswerten, dann das gespeicherte Design mit seinem Cache öffnen.
M=/home/markus/solidcraft-p2/out/10601/mess
BASE=/home/markus/solidcraft-p2/out/bin/cli-base
BRANCH=/home/markus/solidcraft-target-p2/release/solidcraft-cli
cd $M; mkdir -p in base branch
for d in box1500 sheet300 cthr400; do
  [ -f in/$d.sc.plain.sc ] && continue
  timeout 1800 $BASE run $d.json --save in/$d.sc --quiet > /dev/null 2>&1
  (cd in && timeout 1800 $BASE bench-open $d.sc --save prep_$d.sc > /dev/null 2>&1; cp prep_$d.sc.plain.sc $d.sc.plain.sc)
done
for r in 1 2 3; do for d in box1500 sheet300 cthr400; do for v in base branch; do
  B=$BASE; [ $v = branch ] && B=$BRANCH
  l=$(cut -d' ' -f1 /proc/loadavg)
  save=$(cd $v && timeout 1800 $B bench-open ../in/$d.sc.plain.sc --save ${d}_r$r.sc 2>/dev/null | grep '"step":"save"')
  man=$(python3 -I manifest.py $v/${d}_r$r.sc)
  open=$(cd $v && timeout 1800 $B bench-open ${d}_r$r.sc 2>/dev/null | grep '"step":"evaluate"')
  echo "$r $d $v load=$l SAVE $save"
  echo "$r $d $v MAN $man"
  echo "$r $d $v OPEN $open"
done; done; done
touch $M/mess.FERTIG
