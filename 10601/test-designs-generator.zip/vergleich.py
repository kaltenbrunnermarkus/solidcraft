#!/usr/bin/env python3
"""vergleich.py BASE.sc BRANCH.sc: document.json byteweise; je Feature, dessen Zustand beide
Caches behalten, den Zustand vergleichen (Markierungen aufgelöst: Basis inline, Branch über die
Tabelle; Körper über ihre Datensätze ohne Body-Index; übrige Felder direkt)."""
import json, sys, zipfile
def load(p):
    z = zipfile.ZipFile(p)
    return z.read("document.json"), json.loads(z.read("cache/model.json"))["model"]
def expand(runs, table):
    return [table[i] for f, c in runs for i in range(f, f + c)]
def state(m, i):
    s = dict(m["states"][i])
    if "threads" in m:  # Branch: Läufe in die Tabelle
        s["threads"] = expand(s["threads"], m["threads"])
    s["bodies"] = [{k: v for k, v in b.items() if k not in ("body", "names")} | {"names": m["names"][b["names"]]} for b in expand(s["bodies"], m["model_bodies"])]
    s["sketches"] = expand(s["sketches"], m["sketches"])
    s["sheets"] = [m["sheets"][j] for j in s["sheets"]]
    ks = m["sketch_key_sets"]
    def keys(j):
        k = ks[j]; base = keys(k["base"]) if "base" in k else {}
        base = dict(base)
        for f in k["drop"]: base.pop(f, None)
        for f, h in k["set"]: base[f] = h
        return base
    s["sketch_key_set"] = keys(s["sketch_key_set"])
    return s
(da, a), (db, b) = load(sys.argv[1]), load(sys.argv[2])
ok = da == db
if not ok: print("document.json verschieden")
both = diff = 0; thr = 0
for fa, fb in zip(a["features"], b["features"]):
    for k in ("id", "fingerprint", "skipped", "warning", "diagnostics"):
        if fa.get(k) != fb.get(k): ok = False; print("Feature-Feld", k, fa["id"])
    if "state" in fa and "state" in fb:
        both += 1
        sa, sb = state(a, fa["state"]), state(b, fb["state"])
        thr += len(sb["threads"])
        if sa != sb:
            diff += 1; ok = False
            if diff < 4: print("Zustand verschieden bei Feature", fa["id"], [k for k in sa if sa[k] != sb.get(k)])
print(("GLEICH" if ok else "UNGLEICH"), f"| Features {len(a['features'])}, Zustände in beiden {both}, verglichene Markierungen {thr}")
