#!/usr/bin/env python3
"""Writes the kernel comparison cases (truck on main vs SMLib on develop) as
solidcraft-cli scripts: one JSON file per case in ./cases/ next to this file.
Every case is written from scratch from the descriptions in tangency-labs/solidcraft
#3992, #1597, #2076, #1219, #1250, #5126 and #7497; no file from an issue is used.
Usage: python3 generate_cases.py   (then: solidcraft-cli eval cases/<case>.json)"""
import json, math, os

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "cases")
CASES = {}

def case(name, group, what, commands, volume=None):
    CASES[name] = {"about": {"group": group, "what": what,
                             "expected_volume_mm3": volume},
                   "commands": commands}

def c(cmd, **p):
    return {"command": cmd, "params": p}

# ---- Booleans --------------------------------------------------------------
case("boolean-box-cylinder-join", "booleans",
     "box 40x40x20 joined with a cylinder r10 h30 standing on its edge",
     [c("solid.box", corner=[0, 0, 0], length=40, width=40, height=20, body_name="Block"),
      c("solid.cylinder", radius=10, height=30, base=[40, 20, 0], operation="join", targets=["Block"])],
     40*40*20 + math.pi*100*30/2 + math.pi*100*10/2)

case("boolean-equal-cylinders-union", "booleans",
     "two cylinders r10 L60 crossing at right angles, same radius (Steinmetz), joined",
     [c("solid.cylinder", radius=10, height=60, base=[-30, 0, 0], axis=[1, 0, 0], body_name="A"),
      c("solid.cylinder", radius=10, height=60, base=[0, -30, 0], axis=[0, 1, 0], operation="join", targets=["A"])],
     2*math.pi*100*60 - 16/3*1000)

case("boolean-sphere-half-cut", "booleans",
     "sphere r20 at the origin, lower half cut away by a box",
     [c("solid.sphere", center=[0, 0, 0], radius=20, body_name="Ball"),
      c("solid.box", center=[0, 0, -15], length=50, width=50, height=30, operation="cut", targets=["Ball"])],
     2/3*math.pi*20**3)

# ---- Fillet and chamfer ----------------------------------------------------
case("fillet-box-corners-and-rim", "fillet-chamfer",
     "box 60x40x30: 4 vertical edges r5, then the top rim (one tangent chain) r3",
     [c("solid.box", corner=[0, 0, 0], length=60, width=40, height=30, body_name="Box"),
      c("solid.fillet", edges=[[0, 0, 15], [60, 0, 15], [0, 40, 15], [60, 40, 15]], radius=5, name="Corners"),
      c("solid.fillet", edges=[[30, 0, 30]], radius=3, name="Rim")])

case("chamfer-box-all-edges", "fillet-chamfer",
     "box 60x40x30, all 12 edges chamfered 2 mm in one feature",
     [c("solid.box", corner=[0, 0, 0], length=60, width=40, height=30, body_name="Box"),
      c("solid.chamfer", distance=2, edges=[
          [30, 0, 0], [30, 40, 0], [30, 0, 30], [30, 40, 30],
          [0, 20, 0], [60, 20, 0], [0, 20, 30], [60, 20, 30],
          [0, 0, 15], [60, 0, 15], [0, 40, 15], [60, 40, 15]])])

case("fillet-plate-counterbored-holes", "fillet-chamfer",
     "the parametric plate of skills/solidcraft-modeling/reference.md: corner fillets r5, 4 counterbored holes",
     [c("parameters.add", name="L", expression="80 mm"),
      c("parameters.add", name="W", expression="50 mm"),
      c("parameters.add", name="T", expression="6 mm"),
      c("parameters.add", name="inset", expression="8 mm"),
      c("sketch.create", plane="XY", name="PlateSketch"),
      c("sketch.draw.dimensioned", command="sketch.rectangle.center",
        params={"center": [0, 0], "corner": [40, 25]}, dimensions={"width": "L", "height": "W"}),
      c("sketch.finish"),
      c("solid.extrude", distance="T", name="Plate"),
      c("solid.fillet", edges=[[40, 25, 3], [-40, 25, 3], [40, -25, 3], [-40, -25, 3]], radius=5, name="Corners"),
      c("sketch.create", plane="XY", name="HolePts", offset="T"),
      c("sketch.point", point=[32, 17]),
      c("sketch.dimension", entities=["origin", "p1"], type="horizontal", value="L/2 - inset"),
      c("sketch.dimension", entities=["origin", "p1"], type="vertical", value="W/2 - inset"),
      c("sketch.finish"),
      c("solid.hole", sketch="HolePts", diameter=3.4, type="counterbore", cb_diameter=6.5, cb_depth=3.3, name="Hole"),
      c("solid.pattern.rectangular", features=["Hole"], dir1=[-1, 0, 0], count1=2, spacing1="L - 2*inset",
        dir2=[0, -1, 0], count2=2, spacing2="W - 2*inset", name="Holes")],
     23335.2)

# ---- Shell -----------------------------------------------------------------
case("shell-open-box", "shell",
     "box 60x40x30, top face removed, wall 2",
     [c("solid.box", corner=[0, 0, 0], length=60, width=40, height=30, body_name="Box"),
      c("solid.shell", faces=[[30, 20, 30]], thickness=2)],
     60*40*30 - 56*36*28)

case("shell-filleted-box", "shell",
     "box 60x40x30 with vertical edges r5, then shelled open at the top, wall 2",
     [c("solid.box", corner=[0, 0, 0], length=60, width=40, height=30, body_name="Box"),
      c("solid.fillet", edges=[[0, 0, 15], [60, 0, 15], [0, 40, 15], [60, 40, 15]], radius=5),
      c("solid.shell", faces=[[30, 20, 30]], thickness=2)])

case("shell-cylinder-cup", "shell",
     "cylinder r20 h40, top removed, wall 1.5",
     [c("solid.cylinder", radius=20, height=40, body_name="Cup"),
      c("solid.shell", faces=[[0, 0, 40]], thickness=1.5)],
     math.pi*(400*40 - 18.5**2*38.5))

# ---- Patterns with many holes ----------------------------------------------
def hole_grid(name, n, pitch, d):
    size = n*pitch
    case(name, "patterns",
         f"plate {size}x{size}x5 with one through hole d{d}, patterned {n}x{n} at pitch {pitch} ({n*n} holes)",
         [c("solid.box", corner=[0, 0, 0], length=size, width=size, height=5, body_name="Plate"),
          c("solid.hole", position=[pitch/2, pitch/2, 5], diameter=d, name="Hole"),
          c("solid.pattern.rectangular", features=["Hole"], dir1=[1, 0, 0], count1=n, spacing1=pitch,
            dir2=[0, 1, 0], count2=n, spacing2=pitch, name="Holes")],
         size*size*5 - n*n*math.pi*(d/2)**2*5)

hole_grid("pattern-holes-10x10", 10, 10, 4)
hole_grid("pattern-holes-20x20", 20, 6, 3)

case("pattern-flange-36-holes", "patterns",
     "flange r60 h10, one bolt hole d5 on r50, circular pattern of 36",
     [c("solid.cylinder", radius=60, height=10, body_name="Flange"),
      c("solid.cylinder", diameter=5, height=12, base=[50, 0, -1], operation="cut", targets=["Flange"], name="BoltHole"),
      c("solid.pattern.circular", features=["BoltHole"], axis="Z", count=36, name="Bolts")],
     math.pi*3600*10 - 36*math.pi*6.25*10)

case("pattern-pins-joined-10x10", "patterns",
     "plate 100x100x5 with one pin r2 h10 joined on top, patterned 10x10 (#2076)",
     [c("solid.box", corner=[0, 0, 0], length=100, width=100, height=5, body_name="Plate"),
      c("solid.cylinder", radius=2, height=10, base=[5, 5, 5], operation="join", targets=["Plate"], name="Pin"),
      c("solid.pattern.rectangular", features=["Pin"], dir1=[1, 0, 0], count1=10, spacing1=10,
        dir2=[0, 1, 0], count2=10, spacing2=10, name="Pins")],
     100*100*5 + 100*math.pi*4*10)

# ---- Large planar model: Menger sponge -------------------------------------
def menger_bars(side, level):
    """The through bars that carve a Menger sponge of `level` out of a cube [0, side]^3:
    for each axis, the holes of the Sierpinski carpet, each as one box through the cube."""
    holes = []  # (u, v, size) in the plane across the axis
    cells = [(0.0, 0.0)]
    size = side
    for _ in range(level):
        sub = size/3
        nxt = []
        for (u, v) in cells:
            holes.append((u + sub, v + sub, sub))
            for i in range(3):
                for j in range(3):
                    if (i, j) != (1, 1):
                        nxt.append((u + i*sub, v + j*sub))
        cells, size = nxt, sub
    bars = []
    long = side + 2
    for axis in range(3):
        for (u, v, s) in holes:
            cu, cv = u + s/2, v + s/2
            if axis == 0:
                bars.append(dict(center=[side/2, cu, cv], length=long, width=s, height=s))
            elif axis == 1:
                bars.append(dict(center=[cu, side/2, cv], length=s, width=long, height=s))
            else:
                bars.append(dict(center=[cu, cv, side/2], length=s, width=s, height=long))
    return bars

bars2 = menger_bars(45, 2)
case("menger-level2-cuts", "large-planar",
     f"Menger sponge level 2, side 45: a cube with {len(bars2)} box cuts, one feature each (#7497, #5126)",
     [c("solid.box", corner=[0, 0, 0], length=45, width=45, height=45, body_name="Sponge")]
     + [c("solid.box", operation="cut", targets=["Sponge"], **b) for b in bars2],
     45**3*(20/27)**2)

bars3 = menger_bars(135, 3)
case("menger-level3-cuts", "large-planar",
     f"Menger sponge level 3, side 135: a cube with {len(bars3)} box cuts, one feature each (#7497, #5126)",
     [c("solid.box", corner=[0, 0, 0], length=135, width=135, height=135, body_name="Sponge")]
     + [c("solid.box", operation="cut", targets=["Sponge"], **b) for b in bars3],
     135**3*(20/27)**3)

case("menger-level3-one-combine", "large-planar",
     f"Menger sponge level 3, side 135: {len(bars3)} bar bodies cut from the cube in one Combine (#7497, #5126)",
     [c("solid.box", corner=[0, 0, 0], length=135, width=135, height=135, body_name="Sponge")]
     + [c("solid.box", body_name=f"Bar{i+1}", **b) for i, b in enumerate(bars3)]
     + [c("solid.combine", target="Sponge", tools=[f"Bar{i+1}" for i in range(len(bars3))], operation="cut")],
     135**3*(20/27)**3)

# ---- Loft and sweep --------------------------------------------------------
def plane_z(z):
    return {"origin": [0.0, 0.0, float(z)], "x_dir": [1, 0, 0], "y_dir": [0, 1, 0]}

case("loft-square-to-circle", "loft-sweep",
     "loft from a 20x20 square at z0 to a circle r10 at z20",
     [c("sketch.create", plane=plane_z(0), name="Square"),
      c("sketch.rectangle.center", center=[0, 0], corner=[10, 10]),
      c("sketch.finish"),
      c("sketch.create", plane=plane_z(20), name="Circle"),
      c("sketch.circle.center", center=[0, 0], radius=10),
      c("sketch.finish"),
      c("solid.loft", sections=[{"sketch": "Square"}, {"sketch": "Circle"}], operation="new")])

case("loft-three-sections-on-box", "loft-sweep",
     "loft circle r12 -> square 16 -> circle r6, standing on a box and joined to it",
     [c("solid.box", center=[0, 0, -5], length=40, width=40, height=10, body_name="Base"),
      c("sketch.create", plane=plane_z(0), name="S1"),
      c("sketch.circle.center", center=[0, 0], radius=12),
      c("sketch.finish"),
      c("sketch.create", plane=plane_z(15), name="S2"),
      c("sketch.rectangle.center", center=[0, 0], corner=[8, 8]),
      c("sketch.finish"),
      c("sketch.create", plane=plane_z(30), name="S3"),
      c("sketch.circle.center", center=[0, 0], radius=6),
      c("sketch.finish"),
      c("solid.loft", sections=[{"sketch": "S1"}, {"sketch": "S2"}, {"sketch": "S3"}], operation="join", targets=["Base"])])

path = [c("sketch.create", plane=plane_z(0), name="Path"),
        c("sketch.line", points=[[-22, -20], [22, -20]], infer=False, ids=["l1"]),
        c("sketch.arc.center_point", center=[22, -12], start=[22, -20], end=[30, -12]),
        c("sketch.line", points=[[30, -12], [30, 12]], infer=False, ids=["l2"]),
        c("sketch.arc.center_point", center=[22, 12], start=[30, 12], end=[22, 20]),
        c("sketch.line", points=[[22, 20], [-22, 20]], infer=False, ids=["l3"]),
        c("sketch.arc.center_point", center=[-22, 12], start=[-22, 20], end=[-30, 12]),
        c("sketch.line", points=[[-30, 12], [-30, -12]], infer=False, ids=["l4"]),
        c("sketch.arc.center_point", center=[-22, -12], start=[-30, -12], end=[-22, -20]),
        c("sketch.finish")]
case("sweep-rectangle-round-closed-path", "loft-sweep",
     "4x3 rectangle swept round a closed rounded-rectangle path (60x40, corners r8)",
     path + [c("sketch.create", plane={"origin": [0.0, -20.0, 0.0], "x_dir": [0, 1, 0], "y_dir": [0, 0, 1]}, name="Prof"),
             c("sketch.rectangle.center", center=[0, 0], corner=[2, 1.5]),
             c("sketch.finish"),
             c("solid.sweep", sketch="Prof", path_sketch="Path",
               path=["l1", "a1", "l2", "a2", "l3", "a3", "l4", "a4"], operation="new")],
     12*(2*44 + 2*24 + 2*math.pi*8))  # Pappus: area 12 x path length

# ---- Threads ---------------------------------------------------------------
case("tapped-holes-plate", "threads",
     "plate 100x40x12 with tapped holes M3, M5, M8, M8.5x1 and a blind M12 (hole tool, cosmetic)",
     [c("solid.box", corner=[0, 0, 0], length=100, width=40, height=12, body_name="Plate"),
      c("solid.hole", position=[10, 20, 12], thread="M3"),
      c("solid.hole", position=[25, 20, 12], thread="M5"),
      c("solid.hole", position=[45, 20, 12], thread="M8"),
      c("solid.hole", position=[65, 20, 12], thread="M8.5x1"),
      c("solid.hole", position=[88, 20, 12], thread="M12", depth=8)])

case("modeled-thread-m10-shaft", "threads",
     "shaft d10 h30 with a modelled external M10 thread over its length (#1250)",
     [c("solid.cylinder", radius=5, height=30, body_name="Shaft"),
      c("solid.thread", face=[5, 0, 15], designation="M10", modeled=True)])

if __name__ == "__main__":
    os.makedirs(OUT, exist_ok=True)
    for name, data in CASES.items():
        with open(os.path.join(OUT, name + ".json"), "w") as f:
            json.dump(data, f, indent=1)
    print(len(CASES), "cases written to", OUT)
