#!/usr/bin/env python3
"""Writes cases/menger-level3-union-of-20.json: a Menger sponge of level 3 built the way
Werner1303 and jyviko built it in tangency-labs/solidcraft #3992 / #5126 (alle20.json):
level 1, 2 and 3 are each one Combine (join) of 20 bodies that touch face to face.
Written from that description; no file from the issues is used. Copies are made with
solid.move copy=true, which names them "<body> (2)" .. "<body> (20)".
Usage: python3 generate_menger_union.py"""
import json, os

HERE = os.path.dirname(os.path.abspath(__file__))
CUBE = 5.0  # level-0 cube, as in #5126

def c(cmd, **p):
    return {"command": cmd, "params": p}

# The 20 of 27 cells a Menger step keeps: at most one coordinate is the middle one.
KEEP = [(i, j, k) for k in range(3) for j in range(3) for i in range(3)
        if [i, j, k].count(1) <= 1]
assert len(KEEP) == 20

def level(body, cell):
    """19 copies of `body` (a cube of side `cell`) at the other kept cells, then one join."""
    cmds = [c("solid.move", bodies=[body], translate=[i*cell, j*cell, k*cell], copy=True)
            for (i, j, k) in KEEP[1:]]
    cmds.append(c("solid.combine", target=body, operation="join",
                  tools=[f"{body} ({n})" for n in range(2, 21)]))
    return cmds

cmds = [c("solid.box", corner=[0, 0, 0], length=CUBE, width=CUBE, height=CUBE, body_name="Sponge")]
for lv in range(3):
    cmds += level("Sponge", CUBE * 3**lv)

side = CUBE * 27
doc = {"about": {"group": "large-planar",
                 "what": "Menger sponge level 3, side 135: levels 1, 2 and 3 each one join of 20 "
                         "face-touching bodies, the last one 20 level-2 sub-sponges (#3992, #5126)",
                 "expected_volume_mm3": side**3 * (20/27)**3},
       "commands": cmds}
with open(os.path.join(HERE, "cases", "menger-level3-union-of-20.json"), "w") as f:
    json.dump(doc, f, indent=1)
print(len(cmds), "commands, expected volume", doc["about"]["expected_volume_mm3"])
