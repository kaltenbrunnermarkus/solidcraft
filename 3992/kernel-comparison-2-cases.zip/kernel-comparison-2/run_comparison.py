#!/usr/bin/env python3
"""Runs every case in cases/ with both CLIs, one run at a time, alternating the kernels:
round 1 A, B; round 2 B, A; round 3 A, B (A = v0.30.1, B = v0.40.0-rc.1). Each run is a full
rebuild (`solidcraft-cli eval`), limited by `timeout`. Before each run the load (uptime)
is recorded. A kernel that times out is not run again for that case. Writes results/<case>.<kernel>.<round>.json (measurement) and results/runs.jsonl.
Usage: python3 run_comparison.py BIN_DIR RESULTS_DIR [case ...]"""
import json, os, subprocess, sys, time

TIMEOUT_S = 300
A, B = "0.30.1", "0.40.0-rc.1"
HERE = os.path.dirname(os.path.abspath(__file__))

def main():
    bindir, res = sys.argv[1], sys.argv[2]
    names = sys.argv[3:] or sorted(f[:-5] for f in os.listdir(os.path.join(HERE, "cases")) if f.endswith(".json"))
    os.makedirs(res, exist_ok=True)
    log = open(os.path.join(res, "runs.jsonl"), "a")
    orders = [[A, B], [B, A], [A, B]]
    for name in names:
        script = os.path.join(HERE, "cases", name + ".json")
        timed_out = set()
        for rnd, order in enumerate(orders, 1):
            for kernel in order:
                if kernel in timed_out:
                    # A timeout is the result; a second 300 s run would tell nothing new.
                    continue
                out = os.path.join(res, f"{name}.{kernel}.{rnd}.json")
                load = subprocess.run(["uptime"], capture_output=True, text=True).stdout.strip()
                cmd = ["timeout", str(TIMEOUT_S), os.path.join(bindir, f"{kernel}-solidcraft-cli"),
                       "eval", script, "--json-out", out]
                t0 = time.monotonic()
                p = subprocess.run(cmd, capture_output=True, text=True)
                dt = time.monotonic() - t0
                rec = {"case": name, "kernel": kernel, "round": rnd, "seconds": round(dt, 3),
                       "exit": p.returncode, "timeout": p.returncode == 124, "uptime": load,
                       "stderr_tail": p.stderr[-1500:], "stdout_tail": p.stdout[-800:]}
                if rec["timeout"]:
                    timed_out.add(kernel)
                log.write(json.dumps(rec) + "\n"); log.flush()
                print(f"{name} {kernel} r{rnd}: exit {p.returncode} {dt:.2f}s", flush=True)

if __name__ == "__main__":
    main()
