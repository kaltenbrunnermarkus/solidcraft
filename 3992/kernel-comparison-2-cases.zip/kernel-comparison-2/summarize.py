#!/usr/bin/env python3
"""Reads results/runs.jsonl and the measurements from run_comparison.py and prints one
JSON line per case: median time per kernel, success or error, and the result figures
(bodies, faces, edges, volume, bounding box), plus how far v0.30.1 and v0.40.0-rc.1 differ.
Usage: python3 summarize.py RESULTS_DIR > summary.jsonl"""
import json, os, statistics, sys

HERE = os.path.dirname(os.path.abspath(__file__))

def figures(path):
    try:
        d = json.load(open(path))
    except (OSError, ValueError):
        return None
    t = d.get("total") or {}
    lo = [min(b["bbox"]["min"][i] for b in d["bodies"]) for i in range(3)] if d.get("bodies") and all("bbox" in b for b in d["bodies"]) else None
    hi = [max(b["bbox"]["max"][i] for b in d["bodies"]) for i in range(3)] if lo else None
    errors = [f"{x.get('name')}: {x.get('error')}" for x in d.get("timeline", []) if x.get("error")]
    warnings = [f"{x.get('name')}: {x.get('warning')}" for x in d.get("timeline", []) if x.get("warning")]
    feature_ms = sum(x.get("ms") or 0 for x in d.get("timeline", []))
    return {"feature_ms": feature_ms, "bodies": d.get("body_count"), "faces": t.get("faces"), "edges": t.get("edges"),
            "vertices": t.get("vertices"), "volume": t.get("volume_mm3"), "area": t.get("area_mm2"),
            "bbox_min": lo, "bbox_max": hi,
            "kernel_faces": sum(b.get("kernel", {}).get("faces", 0) for b in d.get("bodies", [])),
            "shells": sum(b.get("kernel", {}).get("shells", 0) for b in d.get("bodies", [])),
            "measured_by": sorted({str(b.get("measured_by")) for b in d.get("bodies", [])}), "errors": errors, "warnings": warnings}

def same(a, b):
    """Two runs of one kernel agree: equal counts, volume within 1e-9 relative (last bits)."""
    if a is None or b is None:
        return a is b
    keys = ("bodies", "faces", "edges", "vertices", "kernel_faces", "shells")
    va, vb = a["volume"] or 0.0, b["volume"] or 0.0
    return all(a[k] == b[k] for k in keys) and abs(va - vb) <= 1e-9 * max(abs(va), abs(vb), 1.0)

def main():
    res = sys.argv[1]
    runs = [json.loads(l) for l in open(os.path.join(res, "runs.jsonl"))]
    cases = []
    for r in runs:
        if r["case"] not in cases:
            cases.append(r["case"])
    for name in cases:
        about = json.load(open(os.path.join(HERE, "cases", name + ".json")))["about"]
        row = {"case": name, "group": about["group"], "expected_volume": about["expected_volume_mm3"]}
        for k in ("0.30.1", "0.40.0-rc.1"):
            rs = [r for r in runs if r["case"] == name and r["kernel"] == k]
            if not rs:
                continue
            ok = [r for r in rs if r["exit"] == 0]
            fig = None
            for r in ok:
                f = figures(os.path.join(res, f"{name}.{k}.{r['round']}.json"))
                if fig is None:
                    fig = f
                elif not same(f, fig):
                    row.setdefault("unstable", []).append(k)
            err = None
            bad = [r for r in rs if r["exit"] != 0]
            if bad:
                b = bad[0]
                err = "timeout 300 s" if b["timeout"] else (b["stderr_tail"].strip().splitlines() or ["exit %d" % b["exit"]])[-1]
            fms = [f["feature_ms"] for f in (figures(os.path.join(res, f"{name}.{k}.{r['round']}.json")) for r in ok) if f]
            row[k] = {"median_feature_s": round(statistics.median(fms) / 1000, 3) if fms else None, "median_s": statistics.median(r["seconds"] for r in rs), "times": [r["seconds"] for r in rs],
                      "ok_runs": len(ok), "runs": len(rs), "error": err, "result": fig,
                      "uptime": [r["uptime"].split("load average:")[-1].strip() for r in rs]}
        t, s = row.get("0.30.1", {}).get("result"), row.get("0.40.0-rc.1", {}).get("result")
        if t and s and t["volume"] and s["volume"]:
            row["volume_rel_diff"] = abs(t["volume"] - s["volume"]) / max(abs(s["volume"]), 1e-12)
            row["same_topology"] = (t["bodies"], t["faces"], t["edges"]) == (s["bodies"], s["faces"], s["edges"])
        print(json.dumps(row))

if __name__ == "__main__":
    main()
