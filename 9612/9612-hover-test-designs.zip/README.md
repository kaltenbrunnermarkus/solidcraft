# Test designs for P1 (viewport hover)

Made by us with SolidCraft itself, no customer data.

- `split_cylinder.py N` writes a command script: one sketch whose circle is N arcs about the
  same centre (radius 20 mm), extruded 40 mm. The round wall is N cylindrical faces of one
  surface joined by hidden seams (one surface patch), like an imported surface split into many
  faces. Hovering any piece lights the whole wall.
- `split-cylinder-64.solidcraft`, `-256`, `-512`: made with (the kernel joins only some of the
  pieces by seams at 64 and 256 arcs: 2 and 15 pieces per surface; at 512 all 512 are one surface)

      python3 split_cylinder.py 256 > split-cylinder-256.json
      solidcraft-cli run split-cylinder-256.json --quiet --save split-cylinder-256.solidcraft

  (the sketch of many arcs takes a while to build: about 32 s for 256 arcs.)
- `hover_frames.py`: frame time (`ui.inspect` `frame_ms`) while the pointer moves over a fixed
  grid of 60 points across a design in the running app (`solidcraft --control PORT`);
  `--click-at 0.65,0.5` first clicks the wall of the split cylinder (selecting all its pieces).
- `hover_runs.sh DESIGN ROUNDS APP_A APP_B LOG [options]`: runs `hover_frames.py` with two app
  builds alternating, each under its own `xvfb-run`, quitting the app over the control channel.
- `bench_runs.sh ROUNDS TEST_BIN_A TEST_BIN_B LOG`: the headless measurement below with two release
  test binaries alternating.

## Measuring

Highlight build per hover change and the highlight key (release test binary, from `main` and
from the branch, alternating):

    SOLIDCRAFT_SPLIT_CYLINDERS=$PWD/split-cylinder-256.solidcraft:$PWD/split-cylinder-512.solidcraft \
    SOLIDCRAFT_ROVER=/path/to/rover.solidcraft SOLIDCRAFT_GPU=software \
    cargo test -p solidcraft-ui-egui --release --lib scale_tests::smooth_surface_face_hover_cost -- --ignored --nocapture

Frame time while hovering, in the app under Xvfb with the software renderer (main's build and
the branch's alternating):

    hover_runs.sh $PWD/split-cylinder-512.solidcraft 5 main/solidcraft branch/solidcraft cyl.log --click-at 0.65,0.5
    hover_runs.sh /path/to/rover.solidcraft 5 main/solidcraft branch/solidcraft rover.log

The rover measured (5,484 features, 2,116 bodies, 16 MB) is not included here; it is built as
`docs/perf.md` and `examples/demo/record_rover.sh` describe.
