#!/bin/bash
# bench_runs.sh ROUNDS BEFORE AFTER OUTLOG: the release test binaries' hover measurement
# (scale_tests::smooth_surface_face_hover_cost), before and after alternating.
set -u
ROUNDS=$1; A=$2; B=$3; LOG=$4
T=$(cd "$(dirname "$0")" && pwd)
export SOLIDCRAFT_SPLIT_CYLINDERS=$T/split-cylinder-256.solidcraft:$T/split-cylinder-512.solidcraft
export SOLIDCRAFT_ROVER=${SOLIDCRAFT_ROVER:-} SOLIDCRAFT_GPU=software
for r in $(seq 1 "$ROUNDS"); do
  for v in before after; do
    BIN=$A; [ "$v" = after ] && BIN=$B
    echo "run $r $v load $(cut -d' ' -f1 /proc/loadavg)" >> "$LOG"
    (cd "$T/../../crates/ui-egui" && "$BIN" scale_tests::smooth_surface_face_hover_cost --ignored --nocapture 2>&1 | grep -E "HOVER|ROVER|panicked" | sed "s/^/$v $r /") >> "$LOG"
  done
done
echo DONE >> "$LOG"
