#!/usr/bin/env python3
"""Frame time while the pointer hovers a design, in a running SolidCraft (`--control PORT`).

    solidcraft --control 7899 &
    python3 hover_frames.py --port 7899 design.solidcraft [--moves 60] [--rounds 3]

Opens the design, shows it from the iso view fitted, then moves the pointer over a fixed grid of
points across the model (no button), reading `ui.inspect` `frame_ms` (CPU time of the UI frame)
after each move (with --click-at, after clicking there first). Prints one JSON line per round: median, p90, min and max frame_ms, and how many
moves changed what is hovered (each such move builds the highlight again).
"""
import argparse
import json
import os
import statistics
import sys
import time

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "examples", "demo"))
from enclosure_mcp import control  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("design")
    ap.add_argument("--port", type=int, default=7899)
    ap.add_argument("--moves", type=int, default=60)
    ap.add_argument("--rounds", type=int, default=3)
    ap.add_argument("--settle", type=float, default=240, help="seconds to wait at most for the model to be drawn")
    ap.add_argument("--click-at", help="fx,fy: first click there (fractions of the view; selects what is there)")
    a = ap.parse_args()

    def ui(method, params=None):
        r = control(a.port, method, params)
        if not r.get("ok", False):
            raise RuntimeError(f"{method}: {r.get('error')}")
        return r.get("result")

    ui("ui.resize", {"width": 1600, "height": 1000})
    ui("ui.home", {"open": False})
    t0 = time.time()
    ui("ui.file", {"path": os.path.abspath(a.design)})
    time.sleep(1)
    while ui("ui.inspect").get("file_busy"):
        time.sleep(0.5)
    print(json.dumps({"opened_s": round(time.time() - t0, 1)}), flush=True)
    ui("ui.home", {"open": False})
    ui("ui.set", {"showSketches": False, "showOrigin": False})
    ui("ui.view", {"view": "iso"})
    ui("ui.camera", {"fit": True})
    time.sleep(3)
    # A large design is meshed and shown progressively: wait until the model is drawn (the
    # pointer moves keep frames coming), then fit the view again.
    vx, vy, vw, vh = ui("ui.inspect")["viewport"]
    t1 = time.time()
    while time.time() - t1 < a.settle:
        ui("ui.move", {"x": vx + vw * 0.5, "y": vy + vh * 0.5})
        draw = ui("ui.inspect").get("draw") or {}
        if draw.get("triangles", 0) > 0:
            break
        time.sleep(1)
    ui("ui.camera", {"fit": True})
    time.sleep(2)
    print(json.dumps({"drawn_after_s": round(time.time() - t1, 1), "draw": ui("ui.inspect").get("draw")}), flush=True)
    vx, vy, vw, vh = ui("ui.inspect")["viewport"]
    if a.click_at:
        fx, fy = (float(v) for v in a.click_at.split(","))
        ui("ui.move", {"x": vx + vw * fx, "y": vy + vh * fy})
        time.sleep(0.5)
        ui("ui.click", {"x": vx + vw * fx, "y": vy + vh * fy})
        time.sleep(1)
        sel = ui("ui.selection")
        print(json.dumps({"selected": len(sel.get("selection", []))}), flush=True)
    cols = 10
    rows = max(1, a.moves // cols)
    points = [(vx + vw * (0.2 + 0.6 * c / (cols - 1)), vy + vh * (0.2 + 0.6 * r / max(1, rows - 1))) for r in range(rows) for c in range(cols)]
    for rnd in range(a.rounds):
        times, changes, last = [], 0, None
        for x, y in points:
            ui("ui.move", {"x": x, "y": y})
            time.sleep(0.05)
            st = ui("ui.inspect")
            times.append(st["frame_ms"])
            if st["hover"] != last:
                changes += 1
            last = st["hover"]
        times.sort()
        print(json.dumps({
            "round": rnd,
            "moves": len(times),
            "hover_changes": changes,
            "median_ms": round(statistics.median(times), 3),
            "p90_ms": round(times[int(len(times) * 0.9) - 1], 3),
            "min_ms": round(times[0], 3),
            "max_ms": round(times[-1], 3),
        }), flush=True)


if __name__ == "__main__":
    main()
