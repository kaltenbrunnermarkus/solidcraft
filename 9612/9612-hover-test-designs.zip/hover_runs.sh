#!/bin/bash
# hover_runs.sh DESIGN ROUNDS BIN_A BIN_B OUTLOG [hover_frames options]: frame time while hovering DESIGN, BIN_A and BIN_B
# alternating (A B A B ...), ROUNDS runs each. Each run starts the app under its own xvfb-run
# (which ends the X server when the app ends), measures with hover_frames.py and quits the app
# over the control channel (app.quit). Settings live in a scratch folder, not the user's.
set -u
DESIGN=$1; ROUNDS=$2; A=$3; B=$4; LOG=$5; shift 5
HERE=$(cd "$(dirname "$0")" && pwd)
STATE=${TMPDIR:-/tmp}/p1-hover-state
mkdir -p "$STATE/config" "$STATE/data"
export XDG_CONFIG_HOME=$STATE/config XDG_DATA_HOME=$STATE/data
export SOLIDCRAFT_GPU=software WGPU_BACKEND=vulkan VK_DRIVER_FILES=/usr/share/vulkan/icd.d/lvp_icd.json
PORT=7899
for r in $(seq 1 "$ROUNDS"); do
  for v in A B; do
    BIN=$A; [ "$v" = B ] && BIN=$B
    echo "run $r $v load $(cut -d' ' -f1 /proc/loadavg)" >> "$LOG"
    xvfb-run -a -s "-screen 0 1920x1080x24" "$BIN" --control $PORT > "$STATE/app-$r-$v.log" 2>&1 &
    for i in $(seq 1 120); do
      python3 -c "import socket; socket.create_connection(('127.0.0.1', $PORT), 1)" 2>/dev/null && break
      sleep 1
    done
    sleep 2
    python3 "$HERE/hover_frames.py" --port $PORT --rounds 2 "$@" "$DESIGN" | sed "s/^/$v $r /" >> "$LOG" 2>&1
    python3 -c "
import sys; sys.path.insert(0, '$HERE/../../examples/demo')
from enclosure_mcp import control
control($PORT, 'app.quit', {'force': True})" > /dev/null 2>&1
    wait
  done
done
echo DONE >> "$LOG"
