#!/usr/bin/env python3
"""Write a SolidCraft command script: a cylinder whose round wall is N faces of one surface.

    python3 split_cylinder.py N > split-cylinder-N.json
    solidcraft-cli run split-cylinder-N.json --save split-cylinder-N.solidcraft

The circle is drawn as N arcs about one centre, so the extrusion's wall is N cylindrical faces
joined by hidden seams: hovering one lights all N (one surface patch).
"""
import json
import math
import sys

n = int(sys.argv[1]) if len(sys.argv) > 1 else 64
r, height = 20.0, 40.0
pts = [[round(r * math.cos(2 * math.pi * i / n), 12), round(r * math.sin(2 * math.pi * i / n), 12)] for i in range(n)]
steps = [{"command": "sketch.create", "params": {"plane": "XY"}}]
for i in range(n):
    steps.append({"command": "sketch.arc.center_point", "params": {"center": [0, 0], "start": pts[i], "end": pts[(i + 1) % n]}})
steps.append({"command": "sketch.finish", "params": {}})
steps.append({"command": "solid.extrude", "params": {"sketch": 1, "distance": height, "name": "Wall"}})
json.dump(steps, sys.stdout, indent=1)
