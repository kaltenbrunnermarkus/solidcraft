# Test data and measurement for P2 (mesh export)

Everything here was made for this measurement; no customer data, no downloaded files.

- `gen_plate.py`: writes `plate_holes.json`, a `solidcraft-cli run` script that builds one body:
  a 200 x 200 x 10 mm plate with a 12 x 12 grid of 6 mm holes (`python3 gen_plate.py 12 > plate_holes.json`).
  This is the single large, finely meshed body (finest 3MF: about 280,000 triangles).
- The rover is the design in the repository: `assets/render/selene/source/SELENE-showcase.solidcraft`
  (Rover-v7 lineage, 1,418 exported bodies).
- `export_script.py OUTDIR [--short]`: a run script with one `file.export` per format and quality
  (binary STL, ASCII STL, 3MF, 3MF with face tags, OBJ; standard and finest). `--short` (used for
  the rover) leaves out the tagged 3MF and the finest ASCII STL (4 GB).
- `measure.sh DESIGN TAG REPS [--short]`: alternates `out/bin/cli-before` (release build of the
  branch's base) and `out/bin/cli-after` (release build of the branch), REPS pairs, the order
  flipped every pair; each run is a new process (`--timings` gives each export's ms) under
  `/usr/bin/time`; after every pair the sha256 of every written file is compared
  (`out/mess/TAG-sha.log`).
- `summarize.py TAG`: the table of medians and ranges.

Reproduce:

    CARGO_TARGET_DIR=... cargo build --release -p solidcraft-cli   # once on the base, once on the branch
    cp .../release/solidcraft-cli out/bin/cli-before               # resp. cli-after
    python3 out/testdaten/gen_plate.py 12 > out/testdaten/plate_holes.json
    out/testdaten/measure.sh $PWD/out/testdaten/plate_holes.json plate 5
    out/testdaten/measure.sh $PWD/assets/render/selene/source/SELENE-showcase.solidcraft rover 5 --short
    python3 out/testdaten/summarize.py plate; python3 out/testdaten/summarize.py rover
