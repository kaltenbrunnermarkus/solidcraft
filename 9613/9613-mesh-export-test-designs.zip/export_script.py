#!/usr/bin/env python3
"""Write a solidcraft-cli run script exporting all bodies into OUTDIR, at standard and finest
quality: binary STL, ASCII STL, 3MF, 3MF with face tags and OBJ (with --short: binary STL, 3MF
and OBJ at both qualities and ASCII STL at standard only, as the rover's finest ASCII STL is 4 GB).

    python3 export_script.py OUTDIR [--short] > exports.json
"""
import json
import sys

out = sys.argv[1]
short = "--short" in sys.argv
formats = [("bin.stl", {}), ("ascii.stl", {"format": "stl-ascii"}), ("plain.3mf", {}), ("tagged.3mf", {"format": "3mf-tagged"}), ("mesh.obj", {})]
cmds = []
for q in ["standard", "finest"]:
    for name, extra in formats:
        if short and (name == "tagged.3mf" or (name == "ascii.stl" and q == "finest")):
            continue
        p = {"path": f"{out}/{q}-{name}", "quality": q, "overwrite": True}
        p.update(extra)
        cmds.append({"command": "file.export", "params": p})
json.dump({"commands": cmds}, sys.stdout, indent=1)
print()
