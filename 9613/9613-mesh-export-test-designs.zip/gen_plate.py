#!/usr/bin/env python3
"""Write plate_holes.json: one body, a 200 x 200 x 10 mm plate with an N x N grid of 6 mm holes,
for timing mesh exports of a single large, finely meshed body (P2, mesh export).

    python3 gen_plate.py [N] > plate_holes.json      (default N = 12)
"""
import json
import sys

n = int(sys.argv[1]) if len(sys.argv) > 1 else 12
pitch = 200.0 / n
cmds = [
    {"command": "sketch.create", "params": {"plane": "XY", "name": "Plate"}},
    {"command": "sketch.line", "params": {"points": [[0, 0], [200, 0], [200, 200], [0, 200]], "closed": True}},
    {"command": "sketch.finish", "params": {}},
    {"command": "solid.extrude", "params": {"distance": 10, "body_name": "Plate"}},
    {"command": "sketch.create", "params": {"plane": "XY", "name": "Holes"}},
]
for i in range(n):
    for j in range(n):
        cmds.append({"command": "sketch.circle.center", "params": {"center": [pitch * (i + 0.5), pitch * (j + 0.5)], "diameter": 6}})
cmds += [
    {"command": "sketch.finish", "params": {}},
    {"command": "solid.extrude", "params": {"distance": 10, "operation": "cut"}},
]
json.dump({"description": f"A 200 x 200 x 10 mm plate with {n} x {n} holes of 6 mm (P2 mesh export timing).", "commands": cmds}, sys.stdout, indent=1)
print()
