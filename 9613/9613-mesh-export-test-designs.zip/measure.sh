#!/bin/bash
# measure.sh DESIGN TAG REPS [--short]: alternate the before and after binaries (out/bin/cli-before,
# out/bin/cli-after) REPS times on DESIGN, each run a new process exporting every format at standard
# and finest quality (export_script.py), and check after each pair that both wrote the same bytes.
# Writes out/mess/TAG-<n>-<before|after>.json (per-command ms), .time (wall, CPU, RSS, load) and
# out/mess/TAG-sha.log; touches out/mess/TAG.FERTIG at the end.
set -u
OUT=$(cd "$(dirname "$0")/.." && pwd); DESIGN=$1; TAG=$2; REPS=$3; SHORT=${4:-}
M=$OUT/mess; mkdir -p "$M/$TAG-before" "$M/$TAG-after"
for w in before after; do python3 "$OUT/testdaten/export_script.py" "$M/$TAG-$w" $SHORT > "$M/$TAG-$w-script.json"; done
: > "$M/$TAG-sha.log"
for i in $(seq 1 "$REPS"); do
  if [ $((i % 2)) = 1 ]; then order="before after"; else order="after before"; fi
  for w in $order; do
    load=$(cut -d' ' -f1 /proc/loadavg)
    /usr/bin/time -f "wall %e cpu %U %S rss_kb %M load_start $load" -o "$M/$TAG-$i-$w.time" \
      "$OUT/bin/cli-$w" run "$M/$TAG-$w-script.json" --in "$DESIGN" --timings --quiet > "$M/$TAG-$i-$w.json" 2> "$M/$TAG-$i-$w.err"
  done
  (cd "$M/$TAG-before" && for f in *; do
     a=$(sha256sum < "$f" | cut -c1-64); b=$(sha256sum < "../$TAG-after/$f" | cut -c1-64)
     [ "$a" = "$b" ] && echo "rep $i same $f $a" || echo "rep $i DIFF $f $a $b"
   done) >> "$M/$TAG-sha.log"
done
touch "$M/$TAG.FERTIG"
