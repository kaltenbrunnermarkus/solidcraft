#!/usr/bin/env python3
"""Median and range of each export's ms over the runs measure.sh wrote: summarize.py TAG"""
import json, glob, statistics, sys, os
M = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "mess")
tag = sys.argv[1]
script = json.load(open(f"{M}/{tag}-before-script.json"))["commands"]
names = [os.path.basename(c["params"]["path"]) for c in script]
res = {}
for w in ["before", "after"]:
    runs = []
    for f in sorted(glob.glob(f"{M}/{tag}-*-{w}.json")):
        d = json.load(open(f))
        ms = [t["ms"] for t in d["timings"]]
        tm = open(f[:-5] + ".time").read().split()
        runs.append((ms, float(tm[1]), float(tm[3]) + float(tm[4]), float(tm[8])))
    res[w] = runs
def fmt(v): return f"{statistics.median(v):,.0f} ({min(v):,.0f}–{max(v):,.0f})"
print(f"| Export | before ms | after ms | change |\n|---|---:|---:|---:|")
for i, n in enumerate(names):
    b = [r[0][i] for r in res["before"]]; a = [r[0][i] for r in res["after"]]
    print(f"| {n} | {fmt(b)} | {fmt(a)} | {statistics.median(a)/statistics.median(b)-1:+.0%} |")
for k, lab in [(1, "process wall s"), (2, "process CPU s")]:
    b = [r[k] for r in res["before"]]; a = [r[k] for r in res["after"]]
    print(f"| {lab} | {statistics.median(b):.1f} ({min(b):.1f}–{max(b):.1f}) | {statistics.median(a):.1f} ({min(a):.1f}–{max(a):.1f}) | {statistics.median(a)/statistics.median(b)-1:+.0%} |")
loads = [r[3] for w in res for r in res[w]]
print(f"\nruns: {len(res['before'])} + {len(res['after'])}; 1-min load at start {min(loads):.0f}–{max(loads):.0f}")
