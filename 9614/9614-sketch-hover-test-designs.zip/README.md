# Sketch hover test designs (P3)

Made by us with `gen_sketch_hover.py` (no outside data, no customer data):

```sh
python3 out/testdaten/gen_sketch_hover.py out/testdaten
```

- `hover-circles.json`: one sketch on XY: a 820 x 820 mm rectangle, 20 x 20 circles
  (r 12 mm, 40 mm pitch), 20 lines through the circle rows, 100 open three-point arcs.
  About 900 curves and 1,200 profiles (the plate with its holes, discs and half discs).
- `hover-splines.json`: one sketch on XY: 30 horizontal lines crossed by 30 fit-point
  splines (22 points each), plus 30 short lines between them for Extend.

Both are `solidcraft-cli run` scripts (`{"commands": [...]}`); they end with the sketch still
being edited, so they can also be run with `solidcraft-cli run <file> --save x.sc`.

## Measuring

The ignored test `sketch_hover_timing` in `crates/ui-egui/src/pick_index_tests.rs` runs a
script into a headless UI harness (1600 x 1000), fits the view and times whole UI frames
per mouse move (one `PointerMoved` per frame) over 120 cursor positions (points on the first
20 lines, then a grid), with no tool, with Trim and with Extend; then the profile lookup
under the cursor (`profile_at_point`) and the Trim piece on their own.

```sh
export SOLIDCRAFT_GPU=software WGPU_BACKEND=vulkan VK_DRIVER_FILES=/usr/share/vulkan/icd.d/lvp_icd.json
SOLIDCRAFT_BENCH_SKETCH=$PWD/out/testdaten/hover-circles.json \
  cargo test --release -p solidcraft-ui-egui --lib sketch_hover_timing -- --ignored --nocapture
```

The "before" numbers come from the same test copied onto `origin/main` (1cf5f8392), built
with the same release profile and run alternately with the branch (`out/run-bench.sh`).
