#!/usr/bin/env python3
"""Writes the two sketch-hover test designs as solidcraft-cli scripts (made by us, no outside data).

hover-circles.json: a 840 x 840 mm plate outline with 20 x 20 circles (r 12 mm, 40 mm pitch),
20 lines through the circle rows, and 100 three-point arcs between the circles.
hover-splines.json: 30 horizontal lines crossed by 30 fit-point splines, plus 30 short lines
between them for Extend.
"""
import json, math, sys, os

out = sys.argv[1] if len(sys.argv) > 1 else os.path.dirname(os.path.abspath(__file__))

def script(desc, cmds):
    return {"description": desc, "commands": [{"command": c, "params": p} for c, p in cmds]}

c = [("sketch.create", {"plane": "XY"}),
     ("sketch.rectangle.two_point", {"p0": [-20, -20], "p1": [800, 800]})]
for i in range(20):
    for j in range(20):
        c.append(("sketch.circle.center", {"center": [i * 40 + 10, j * 40 + 10], "radius": 12}))
for j in range(20):
    c.append(("sketch.line", {"points": [[-10, j * 40 + 10], [790, j * 40 + 10]], "connect": False}))
for k in range(100):
    i, j = k % 10, k // 10
    x, y = i * 80 + 30, j * 80 + 30
    c.append(("sketch.arc.three_point", {"start": [x - 6, y], "end": [x + 6, y], "through": [x, y + 6]}))

json.dump(script("Sketch hover test: plate outline, 400 circles, 20 lines, 100 arcs", c), open(os.path.join(out, "hover-circles.json"), "w"), indent=1)

s = [("sketch.create", {"plane": "XY"})]
for j in range(30):
    s.append(("sketch.line", {"points": [[0, j * 20], [600, j * 20]], "connect": False}))
for i in range(30):
    x = i * 20 + 5
    pts = [[x + 6 * math.sin(k * 0.7 + i), k * 30 - 10] for k in range(22)]
    s.append(("sketch.spline.fit_point", {"points": [[round(a, 3), round(b, 3)] for a, b in pts]}))
for k in range(30):
    x, y = (k % 6) * 100 + 40, (k // 6) * 120 + 30
    s.append(("sketch.line", {"points": [[x, y], [x + 4, y + 3]], "connect": False}))

json.dump(script("Sketch hover test: 30 lines crossed by 30 splines, 30 short lines", s), open(os.path.join(out, "hover-splines.json"), "w"), indent=1)
